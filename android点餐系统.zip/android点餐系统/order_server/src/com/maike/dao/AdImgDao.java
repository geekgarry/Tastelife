package com.maike.dao;

import java.util.List;

import com.maike.bean.Advertise;

public interface AdImgDao {
	/**
	 * 添加图片
	 */
	int addAdvertise(Advertise advertise);

	/**
	 * 图片列表
	 * @return
	 */
	List<Advertise> getAllAdvertises();

	/**
	 * 删除图片
	 * @param id
	 */
	int deleteAdvertise(Integer id);

	/**
	 * 修改视频
	 * @param video
	 */
	int updateAdvertise(Advertise advertise);

}

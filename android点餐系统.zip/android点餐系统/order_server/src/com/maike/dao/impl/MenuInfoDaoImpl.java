package com.maike.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.maike.bean.MenuIntroduce;
import com.maike.dao.MenuInfoDao;
import com.maike.util.DBUtil;

public class MenuInfoDaoImpl implements MenuInfoDao {
	public int addMenuIntroduce(MenuIntroduce muinfo) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "insert into menutb(id,name,introduce,image,type,do_way,star,create_dt)values(?,?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatement3(conn, sql, muinfo.getId(),muinfo.getName(),muinfo.getIntroduce(), muinfo.getImage(),
					muinfo.getType(),muinfo.getDo_way(),muinfo.getStar(),muinfo.getCreate_dt());
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	public List<MenuIntroduce> getAllMenuIntroduce() {
		// TODO Auto-generated method stub
		List<MenuIntroduce> list = new ArrayList<MenuIntroduce>();
		String sql = "select * from menutb";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				MenuIntroduce muinfo = new MenuIntroduce();
				muinfo.setId(rs.getInt("id"));
				muinfo.setName(rs.getString("name"));
				muinfo.setIntroduce(rs.getString("introduce"));
				muinfo.setImage(rs.getString("image"));
				muinfo.setType(rs.getString("type"));
				muinfo.setDo_way(rs.getString("do_way"));
				muinfo.setStar(rs.getString("star"));
				muinfo.setCreate_dt(rs.getString("create_dt"));
				list.add(muinfo);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt, rs);
		}
		
		return list;
	}

	public int deleteMenuIntroduce(Integer id) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "delete from menutb where id=" + id;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	public int updateMenuIntroduce(MenuIntroduce muinfo) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "update menutb set name=?,introduce=?,image=?,type=?,do_way=?,star=?,create_dt=NOW() where id=?";
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();

			pstmt = DBUtil.getPreparedStatement4(conn, sql,muinfo.getName(),muinfo.getIntroduce(),muinfo.getImage(),
					muinfo.getType(),muinfo.getDo_way(),muinfo.getStar(),muinfo.getId());
			flag = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(muinfo.getId() + " ：修改出错！");
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}
}

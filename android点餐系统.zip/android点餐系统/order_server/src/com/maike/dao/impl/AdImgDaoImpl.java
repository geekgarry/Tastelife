package com.maike.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.maike.bean.Advertise;
import com.maike.bean.Order;
import com.maike.dao.AdImgDao;
import com.maike.util.DBUtil;

public class AdImgDaoImpl implements AdImgDao{

	@Override
	public int addAdvertise(Advertise advertise) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "insert into adimg(id,content,image,up_date)values(?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatement1(conn, sql, advertise.getId(),advertise.getContent(),advertise.getImage(),advertise.getUp_date());
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	@Override
	public List<Advertise> getAllAdvertises() {
		// TODO Auto-generated method stub
		List<Advertise> list = new ArrayList<Advertise>();
		String sql = "select * from adimg";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Advertise advertise = new Advertise();
				advertise.setId(rs.getInt("id"));
				advertise.setContent(rs.getString("content"));
				advertise.setImage(rs.getString("image"));
				advertise.setUp_date(rs.getString("up_date"));
				list.add(advertise);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt, rs);
		}
		
		return list;
	}

	@Override
	public int deleteAdvertise(Integer id) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "delete from adimg where id=" + id;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	@Override
	public int updateAdvertise(Advertise advertise) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "update adimg set content=?,image=?,up_date=NOW() where id=?";
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();

			pstmt = DBUtil.getPreparedStatement2(conn, sql,advertise.getContent(),advertise.getImage(),advertise.getId());
			flag = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(advertise.getId() + " ：修改出错！");
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

}

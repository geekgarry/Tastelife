package com.maike.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.maike.bean.BeginImage;
import com.maike.dao.BeginImageDao;
import com.maike.util.DBUtil;

public class BeginImageDaoImpl implements BeginImageDao{
	public int addBeginImage(BeginImage beimg) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "insert into beimg(id,content,image,create_dt)values(?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatement1(conn, sql, beimg.getId(),beimg.getContent(),beimg.getImage(),beimg.getCreate_dt());
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	@Override
	public List<BeginImage> getAllBeginImage() {
		// TODO Auto-generated method stub
		List<BeginImage> list = new ArrayList<BeginImage>();
		String sql = "select * from beimg";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			rs = pstmt.executeQuery();
			while(rs.next()){
				BeginImage beimg = new BeginImage();
				beimg.setId(rs.getInt("id"));
				beimg.setContent(rs.getString("content"));
				beimg.setImage(rs.getString("image"));
				beimg.setCreate_dt(rs.getString("create_dt"));
				list.add(beimg);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt, rs);
		}
		
		return list;
	}

	@Override
	public int deleteBeginImage(Integer id) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "delete from beimg where id=" + id;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();
			pstmt = DBUtil.getPreparedStatemnt(conn, sql);
			flag = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			flag = 0;
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}

	@Override
	public int updateBeginImage(BeginImage beimg) {
		// TODO Auto-generated method stub
		int flag = 0;
		String sql = "update beimg set content=?,image=?,create_dt=NOW() where id=?";
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnForMySql();

			pstmt = DBUtil.getPreparedStatement2(conn, sql,beimg.getContent(),beimg.getImage(),beimg.getId());
			flag = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(beimg.getId() + " ：修改出错！");
			e.printStackTrace();
		} finally{
			DBUtil.CloseResources(conn, pstmt);
		}
		
		return flag;
	}
}

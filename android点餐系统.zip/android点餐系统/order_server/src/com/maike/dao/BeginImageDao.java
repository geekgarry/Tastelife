package com.maike.dao;

import java.util.List;

import com.maike.bean.BeginImage;

public interface BeginImageDao {
	/**
	 * 添加图片
	 */
	int addBeginImage(BeginImage beimg);

	/**
	 * 图片列表
	 * @return
	 */
	List<BeginImage> getAllBeginImage();

	/**
	 * 删除图片
	 * @param id
	 */
	int deleteBeginImage(Integer id);

	/**
	 * 修改视频
	 * @param video
	 */
	int updateBeginImage(BeginImage beimg);
}

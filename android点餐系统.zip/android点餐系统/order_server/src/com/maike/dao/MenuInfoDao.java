package com.maike.dao;

import java.util.List;

import com.maike.bean.MenuIntroduce;;

public interface MenuInfoDao {
	/**
	 * 添加图片
	 */
	int addMenuIntroduce(MenuIntroduce menuinfo);

	/**
	 * 图片列表
	 * @return
	 */
	List<MenuIntroduce> getAllMenuIntroduce();

	/**
	 * 删除图片
	 * @param id
	 */
	int deleteMenuIntroduce(Integer id);

	/**
	 * 修改视频
	 * @param video
	 */
	int updateMenuIntroduce(MenuIntroduce menuinfo);
}

package com.maike.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.bean.AdminUser;
import com.maike.bean.User;

/**
 * Servlet implementation class Personal
 */
public class Personal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Personal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		String user=request.getParameter("user");
		try {  
            // 加载数据库驱动，注册到驱动管理器  
            Class.forName("com.mysql.jdbc.Driver");  
            // 数据库连接字符串  
            String url = "jdbc:mysql://localhost:3306/order_db?useUnicode=true&characterEncoding=utf-8";  
            // 数据库用户名  
            String username = "order";  
            // 数据库密码  
            String password = "147258cjj";  
            // 创建Connection连接  
            Connection conn = DriverManager.getConnection(url, username, password);  
            // 添加图书信息的SQL语句  
            String sql = "select * from adminuser where userid=?";  
            // 获取Statement  
            PreparedStatement ps = conn.prepareStatement(sql);  
            ps.setString(1, user);
            ResultSet resultSet = ps.executeQuery();  
  
            List<AdminUser> list = new ArrayList<AdminUser>();  
            while (resultSet.next()) {  
  
            	AdminUser adminuser = new AdminUser();  
            	//user.setId(resultSet.getInt("id"));  
            	adminuser.setId(resultSet.getString("id"));  
            	adminuser.setUserid(resultSet.getString("userid"));  
            	adminuser.setPassword(resultSet.getString("password"));  
                list.add(adminuser);  
  
            }  
            request.setAttribute("list", list);  
            resultSet.close();  
            ps.close();  
            conn.close();  
  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
  
        request.getRequestDispatcher("personal.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

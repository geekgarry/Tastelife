package com.maike.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.dao.MenuInfoDao;
import com.maike.dao.impl.MenuInfoDaoImpl;

/**
 * Servlet implementation class DeleteMenuInfo
 */
public class DeleteMenuInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MenuInfoDao dao=new MenuInfoDaoImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteMenuInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		Integer id = Integer.valueOf(request.getParameter("id"));
		
		dao.deleteMenuIntroduce(id);

//		response.sendRedirect("/manageServlet/listOrder");
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/SelectMenuInfo");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

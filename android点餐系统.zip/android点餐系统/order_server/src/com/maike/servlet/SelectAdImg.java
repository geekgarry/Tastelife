package com.maike.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.bean.Advertise;
import com.maike.bean.Order;
import com.maike.dao.AdImgDao;
import com.maike.dao.impl.AdImgDaoImpl;

/**
 * Servlet implementation class Selecr
 */
public class SelectAdImg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdImgDao dao=new AdImgDaoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectAdImg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		
		List<Advertise> list = dao.getAllAdvertises();
		
		request.setAttribute("list", list);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/selectadimg.jsp");
		
		dispatcher .forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.maike.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.bean.DataBaseBean;
import com.maike.util.DBUtil;

/**
 * Servlet implementation class DeleteAdminUser
 */
public class DeleteAdminUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DataBaseBean db;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAdminUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String user=request.getParameter("user");
		try {  
            /*// 加载数据库驱动，注册到驱动管理器  
            Class.forName("com.mysql.jdbc.Driver");  
            // 数据库连接字符串  
            String url = "jdbc:mysql://localhost:3306/order_db?useUnicode=true&characterEncoding=utf-8";  
            // 数据库用户名  
            String username = "order";  
            // 数据库密码  
            String password = "147258cjj";  
            // 创建Connection连接  
            Connection conn = DriverManager.getConnection(url, username, password);*/
			Connection conn= DBUtil.getConnForMySql();
            // 添加图书信息的SQL语句  
            String sql = "delete from adminuser where userid=?";  
            // 获取Statement  
            PreparedStatement ps = conn.prepareStatement(sql);  
            ps.setString(1, user);
            ps.executeUpdate();  
  
            /*List<AdminUser> list = new ArrayList<AdminUser>();  
            while (resultSet.next()) {
            	AdminUser adminuser = new AdminUser();  
            	//user.setId(resultSet.getInt("id"));  
            	adminuser.setId(resultSet.getString("id"));  
            	adminuser.setUserid(resultSet.getString("userid"));  
            	adminuser.setPassword(resultSet.getString("password"));  
                list.add(adminuser);
            }  
            request.setAttribute("list", list);  
            resultSet.close();*/  
            ps.close();  
            conn.close();  
  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		/*String sql="delete from adminuser where userid=" + user;
		try {
			db.delete(sql);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		out.print("<script>alert('删除成功！');window.location='SelectAdminUser'</script>");
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

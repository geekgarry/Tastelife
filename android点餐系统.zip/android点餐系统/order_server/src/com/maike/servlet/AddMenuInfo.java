package com.maike.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.maike.bean.MenuIntroduce;
import com.maike.dao.MenuInfoDao;
import com.maike.dao.impl.MenuInfoDaoImpl;

/**
 * Servlet implementation class AddMenuInfo
 */
public class AddMenuInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MenuInfoDao dao=new MenuInfoDaoImpl();
	private String Image_PATH="file/menuimg/";
	private String picPath="";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddMenuInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//List<String> imgurls=new ArrayList<String>();
		//String fileName = "";               // 表单字段元素的name属性值
		DiskFileItemFactory factory=new DiskFileItemFactory(); 
		//String uploadFilePath = request.getSession().getServletContext().getRealPath(Image_PATH);
		ServletFileUpload file = new ServletFileUpload(factory);
		file.setSizeMax(4*1024*1024); // 设置最大文件大小，这里是4MB
		MenuIntroduce menuinfo = new MenuIntroduce();
		try {
			@SuppressWarnings("unchecked")
			List<FileItem> list = (List<FileItem>)file.parseRequest(request); 
			Iterator<FileItem> it = list.iterator();
			while(it.hasNext()){ 
				
				FileItem  fileItem=(FileItem)it.next(); 
				if(fileItem.isFormField()){
					if("id".equals(fileItem.getFieldName())){
						menuinfo.setId(Integer.valueOf(fileItem.getString("UTF-8")));
					} else if("name".equals(fileItem.getFieldName())){
						menuinfo.setName(fileItem.getString("UTF-8"));
					}else if("introduce".equals(fileItem.getFieldName())){
						menuinfo.setIntroduce(fileItem.getString("UTF-8"));
					}else if("type".equals(fileItem.getFieldName())){
						menuinfo.setType(fileItem.getString("UTF-8"));
					}else if("do_way".equals(fileItem.getFieldName())){
						menuinfo.setDo_way(fileItem.getString("UTF-8"));
					}else if("star".equals(fileItem.getFieldName())){
						menuinfo.setStar(fileItem.getString("UTF-8"));
					}
				} else {
					// 表单字段的name属性  
                    //fileName = fileItem.getFieldName();
                    if ("imgfile".equals(fileItem.getFieldName())) {
					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
						
						String filename = fileItem.getName();
						String ext = filename.substring(filename.lastIndexOf(".") + 1);
						
						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
							return ;
						}
						if(fileItem.getSize() > 1024 * 1024*3){ // 5 M 
							out.println("图片不能大于3M");
							return ;
						}
						
						String newname = System.currentTimeMillis() + "." + ext;
						
						String str = this.getClass().getResource("/").getPath();
						str = str.replace("WEB-INF/classes/", "").substring(1);
						
						String imagesPath = str + Image_PATH;
						
						File dir = new File(imagesPath);
						if(!dir.exists() && !dir.isDirectory())
							dir.mkdirs();
						
						File realFile=new File(imagesPath, newname);
						fileItem.write(realFile);
						//imgurls.add(menuinfo + newname);
						menuinfo.setImage(Image_PATH + newname);
						/*menuinfo.setImage1(menuinfo + newname);
						menuinfo.setImage2(menuinfo + newname);
						menuinfo.setImage3(menuinfo + newname);
						menuinfo.setImage4(menuinfo + newname);*/
						/*File fullFile = new File(fileItem.getName());  
                        File saveFile = new File(uploadFilePath,  
                                fullFile.getName());  
                        fileItem.write(saveFile);  
                        String newname = fullFile.getName();
                        menuinfo.setImage(Image_PATH + newname);
                        picPath = saveFile.toString();*/
					}
                   }/*else if ("imgfile1".equals(fileItem.getFieldName())) {
    					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
    						
    						String filename = fileItem.getName();
    						String ext = filename.substring(filename.lastIndexOf(".") + 1);
    						
    						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
    							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
    							return ;
    						}
    						if(fileItem.getSize() > 1024 * 1024*3){ // 5 M 
    							out.println("图片不能大于3M");
    							return ;
    						}
    						
    						String newname = System.currentTimeMillis() + "." + ext;
    						
    						String str = this.getClass().getResource("/").getPath();
    						str = str.replace("WEB-INF/classes/", "").substring(1);
    						
    						String imagesPath = str + Image_PATH;
    						
    						File dir = new File(imagesPath);
    						if(!dir.exists() && !dir.isDirectory())
    							dir.mkdirs();
    						
    						File realFile=new File(imagesPath, newname);
    						fileItem.write(realFile);
    						//imgurls.add(menuinfo + newname);
    						menuinfo.setImage1(Image_PATH + newname);
    						menuinfo.setImage1(menuinfo + newname);
    						menuinfo.setImage2(menuinfo + newname);
    						menuinfo.setImage3(menuinfo + newname);
    						menuinfo.setImage4(menuinfo + newname);
    						File fullFile = new File(fileItem.getName());  
                            File saveFile = new File(uploadFilePath,  
                                    fullFile.getName());  
                            fileItem.write(saveFile);  
                            String newname = fullFile.getName();
                            menuinfo.setImage1(Image_PATH + newname);
                            picPath = saveFile.toString();
    					}
                       }else if ("imgfile2".equals(fileItem.getFieldName())) {
    					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
    						
    						String filename = fileItem.getName();
    						String ext = filename.substring(filename.lastIndexOf(".") + 1);
    						
    						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
    							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
    							return ;
    						}
    						if(fileItem.getSize() > 1024 * 1024*3){ // 5 M 
    							out.println("图片不能大于3M");
    							return ;
    						}
    						
    						String newname = System.currentTimeMillis() + "." + ext;
    						
    						String str = this.getClass().getResource("/").getPath();
    						str = str.replace("WEB-INF/classes/", "").substring(1);
    						
    						String imagesPath = str + Image_PATH;
    						
    						File dir = new File(imagesPath);
    						if(!dir.exists() && !dir.isDirectory())
    							dir.mkdirs();
    						
    						File realFile=new File(imagesPath, newname);
    						fileItem.write(realFile);
    						//imgurls.add(menuinfo + newname);
    						menuinfo.setImage2(Image_PATH + newname);
    						menuinfo.setImage1(menuinfo + newname);
    						menuinfo.setImage2(menuinfo + newname);
    						menuinfo.setImage3(menuinfo + newname);
    						menuinfo.setImage4(menuinfo + newname);
    						File fullFile = new File(fileItem.getName());  
                            File saveFile = new File(uploadFilePath,  
                                    fullFile.getName());  
                            fileItem.write(saveFile);  
                            String newname = fullFile.getName();
                            menuinfo.setImage2(Image_PATH + newname);
                            picPath = saveFile.toString();
    					}
                       }*//*else if ("imgfile3".equals(fileItem.getFieldName())) {
    					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
    						
    						String filename = fileItem.getName();
    						String ext = filename.substring(filename.lastIndexOf(".") + 1);
    						
    						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
    							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
    							return ;
    						}
    						if(fileItem.getSize() > 1024 * 1024*3){ // 5 M 
    							out.println("图片不能大于3M");
    							return ;
    						}
    						
    						String newname = System.currentTimeMillis() + "." + ext;
    						
    						String str = this.getClass().getResource("/").getPath();
    						str = str.replace("WEB-INF/classes/", "").substring(1);
    						
    						String imagesPath = str + Image_PATH;
    						
    						File dir = new File(imagesPath);
    						if(!dir.exists() && !dir.isDirectory())
    							dir.mkdirs();
    						
    						File realFile=new File(imagesPath, newname);
    						fileItem.write(realFile);
    						//imgurls.add(menuinfo + newname);
    						menuinfo.setImage3(Image_PATH + newname);
    						menuinfo.setImage1(menuinfo + newname);
    						menuinfo.setImage2(menuinfo + newname);
    						menuinfo.setImage3(menuinfo + newname);
    						menuinfo.setImage4(menuinfo + newname);
    						File fullFile = new File(fileItem.getName());  
                            File saveFile = new File(uploadFilePath,  
                                    fullFile.getName());  
                            fileItem.write(saveFile);  
                            String newname = fullFile.getName();
                            menuinfo.setImage3(Image_PATH + newname);
                            picPath = saveFile.toString();
    					}
                       }else if ("imgfile4".equals(fileItem.getFieldName())) {
    					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
    						
    						String filename = fileItem.getName();
    						String ext = filename.substring(filename.lastIndexOf(".") + 1);
    						
    						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
    							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
    							return ;
    						}
    						if(fileItem.getSize() > 1024 * 1024*3){ // 5 M 
    							out.println("图片不能大于3M");
    							return ;
    						}
    						
    						String newname = System.currentTimeMillis() + "." + ext;
    						
    						String str = this.getClass().getResource("/").getPath();
    						str = str.replace("WEB-INF/classes/", "").substring(1);
    						
    						String imagesPath = str + Image_PATH;
    						
    						File dir = new File(imagesPath);
    						if(!dir.exists() && !dir.isDirectory())
    							dir.mkdirs();
    						
    						File realFile=new File(imagesPath, newname);
    						fileItem.write(realFile);
    						//imgurls.add(menuinfo + newname);
    						menuinfo.setImage4(Image_PATH + newname);
    						menuinfo.setImage1(menuinfo + newname);
    						menuinfo.setImage2(menuinfo + newname);
    						menuinfo.setImage3(menuinfo + newname);
    						menuinfo.setImage4(menuinfo + newname);
    						File fullFile = new File(fileItem.getName());  
                            File saveFile = new File(uploadFilePath,  
                                    fullFile.getName());  
                            fileItem.write(saveFile);  
                            String newname = fullFile.getName();
                            menuinfo.setImage4(Image_PATH + newname);
                            picPath = saveFile.toString();
    					}
                       }*/
				}
			}
			if(dao.addMenuIntroduce(menuinfo)> 0){
				out.println("添加成功");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/addmenuinfo.jsp");
				dispatcher .forward(request, response);
			}else{
				out.println("添加失败");
			}
		} catch (FileUploadException e) {
			out.println("添加失败");
			e.printStackTrace();
		} catch (Exception e) {
			out.println("添加失败");
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.maike.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.maike.bean.Advertise;
import com.maike.dao.AdImgDao;
import com.maike.dao.impl.AdImgDaoImpl;

/**
 * Servlet implementation class UpdateAdImg
 */
public class UpdateAdImg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdImgDao dao=new AdImgDaoImpl();
	private String IMAGE_PATH = "file/adimage/";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateAdImg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		DiskFileItemFactory factory=new DiskFileItemFactory(); 
		
		ServletFileUpload file = new ServletFileUpload(factory);
		Advertise advertise = new Advertise();
		try {
			List list = file.parseRequest(request); 
			@SuppressWarnings("unchecked")
			Iterator<ServletFileUpload> it = list.iterator();
			while(it.hasNext()){ 
				
				FileItem  fileItem=(FileItem)it.next(); 
				if(fileItem.isFormField()){
					if("id".equals(fileItem.getFieldName())){
						advertise.setId(Integer.valueOf(fileItem.getString("UTF-8")));
					}else if("content".equals(fileItem.getFieldName())){
						advertise.setContent(fileItem.getString("UTF-8"));
					}else if("imgfile".equals(fileItem.getFieldName())){
						advertise.setImage(fileItem.getString("UTF-8"));
					}
				} else { 
					if(fileItem.getName()!=null&&!fileItem.getName().equals("")){
						
						String filename = fileItem.getName();
						String ext = filename.substring(filename.lastIndexOf(".") + 1);
						
						if(!"JPEGJPGPNGjpegjpgpngbmp".contains(ext)){
							out.println("图片格式必须为：JPEG、JPG、PNG、jpeg、jpg、png、bmp");
							return ;
						}
						if(fileItem.getSize() > 1024*1024*3){ // 3 M 
							out.println("图片不能大于3M");
							return ;
						}
						
						String newname = System.currentTimeMillis() + "." + ext;
						
						String str = this.getClass().getResource("/").getPath();
						str = str.replace("WEB-INF/classes/", "").substring(1);
						
						String imagesPath = str + IMAGE_PATH;
						
						File dir = new File(imagesPath);
						if(!dir.exists() && !dir.isDirectory())
							dir.mkdirs();
						
						File realFile=new File(imagesPath, newname);
						fileItem.write(realFile);
						
						File old = new File(str, advertise.getImage());
						if(old.exists())
							old.delete();
						
						advertise.setImage(IMAGE_PATH + newname);
					}
				}
			}
			dao.updateAdvertise(advertise);
		} catch (FileUploadException e) {
			out.println("添加失败");
			e.printStackTrace();
		} catch (Exception e) {
			out.println("添加失败");
			e.printStackTrace();
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("/SelectAdImg");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

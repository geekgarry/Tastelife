package com.maike.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.dao.AdImgDao;
import com.maike.dao.impl.AdImgDaoImpl;

/**
 * Servlet implementation class DeleteAdimg
 */
public class DeleteAdimg extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdImgDao dao=new AdImgDaoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAdimg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		Integer id = Integer.valueOf(request.getParameter("id"));
		
		dao.deleteAdvertise(id);

//		response.sendRedirect("/manageServlet/listOrder");
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/SelectAdImg");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	@Override
	public void destroy() {
		super.destroy();
	}
	
	@Override
	public void init() throws ServletException {
		super.init();
	}

}

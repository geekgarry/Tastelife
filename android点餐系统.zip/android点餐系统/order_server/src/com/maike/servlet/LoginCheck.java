package com.maike.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.maike.bean.AdminUser;
import com.maike.util.DBUtil;

/**
 * Servlet implementation class Logincheck
 */
public class LoginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletRequest session;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
				// TODO Auto-generated method stub
				request.setCharacterEncoding("utf-8");
				//PrintWriter out = response.getWriter();
				//String option1=request.getParameter("option1");
				//String opt=new String(option1.getBytes("iso-8859-1"),"utf-8");//当传递数据出现乱码时使用该方法转换
				//out.print("<script>alert(opt); </script>");
				//String teacher=request.getParameter("option1");
				//AdminUser user1=new AdminUser();
				String user=request.getParameter("user");//user1.getId();
				String pwd=request.getParameter("password");//user1.getPassword();
				boolean isValid = false;
				if(user.equals("")||pwd.equals(""))
				{
					response.sendRedirect("login.jsp");
					return;
				}
				/* // 创建oracle数据库驱动实例
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver").newInstance();
				// 连接字符串，格式： "jdbc:数据库驱动名称:连接模式:@数据库服务器ip:端口号:数据库SID"
				String url = "jdbc:odbc:data";
				String username = "system"; // 用户名
				String password = "system"; //密码
				// 获得与数据库的连接
				Connection conn=DriverManager.getConnection("jdbc:odbc:data","system","147258cjj"); */
				
				/*if(option1.equals("dianyuan"))
				{*/
				try {
				Connection conn;
				ResultSet  rs=null;
				PreparedStatement pres = null;// 创建预编译语句对象，一般都是用这个而不用Statement
				//String result = ""; // 查询结果字符串
				conn = DBUtil.getConnForMySql();
				String sql1 ="select * from adminuser where userid=? and password=?";// SQL 字符串
			    // 创建执行语句对象
			    pres=conn.prepareStatement(sql1);
			    pres.setString(1, user);// 设置参数，前面的1表示参数的索引，而不是表中列名的索引  
		      	pres.setString(2, pwd);// 设置参数，前面的1表示参数的索引，而不是表中列名的索引
				//Statement  stmt = conn.createStatement();
			    // 执行sql语句，返回结果集
			    rs   = pres.executeQuery(); 
			    while ( rs.next() )
			    {
			    	/*if(rs.getString(1).equals(user)&&rs.getString(2).equals(pwd))
			    	{
			    		//session.setAttribute("user", user);//<jsp:forward page="index.jsp" />
			    		 response.sendRedirect("index.jsp?user="+user+"");
			    	}else
			    	{
			    		response.sendRedirect("login.jsp");
			    	}*/  
			        //result += "\n 第一个字段内容：" + rs.getString(1) + "<BR>";
			        isValid=true;
			        //response.sendRedirect("index.jsp?user="+user+"");
				 }
			    rs.close();// 关闭结果集
				pres.close(); // 关闭执行语句对象
				conn.close(); // 关闭与数据库的连接
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(isValid){  
				      System.out.println("登录成功！");  
				      //session.setAttribute("user", user);
				      request.setAttribute("user", user);
				      //response.sendRedirect("index.jsp");
				      request.getRequestDispatcher("index.jsp").forward(request, response);
				      return;  
				  }else{  
				      System.out.println("登录失败！");  
				      response.sendRedirect("login.jsp");
				      //response.sendRedirect("index.jsp?user="+user+"");
				      return;  
				  }
	}
	public void init() throws ServletException {
		// Put your code here
	}

}

package com.maike.servlet.order;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.maike.bean.BeginImage;
import com.maike.dao.BeginImageDao;
import com.maike.dao.impl.BeginImageDaoImpl;

/**
 * Servlet implementation class BeginImageServlet
 */
public class BeginImageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BeginImageDao dao=new BeginImageDaoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BeginImageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		List<BeginImage> list = dao.getAllBeginImage();
		
		//request.setAttribute("list", list);
		//out.println(list.toString());
		Gson gson=new Gson();

		String js=gson.toJson(list);

		out.write(js);
		//out.print(js);

		out.flush();

		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

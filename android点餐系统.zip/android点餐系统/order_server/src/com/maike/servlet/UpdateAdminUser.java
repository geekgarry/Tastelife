package com.maike.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.maike.bean.AdminUser;
import com.maike.util.DBUtil;

/**
 * Servlet implementation class UpdateAdminUser
 */
public class UpdateAdminUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateAdminUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String user=request.getParameter("user");
		String pwd=request.getParameter("password");
		try {  
            /*// 加载数据库驱动，注册到驱动管理器  
            Class.forName("com.mysql.jdbc.Driver");  
            // 数据库连接字符串  
            String url = "jdbc:mysql://localhost:3306/order_db?useUnicode=true&characterEncoding=utf-8";  
            // 数据库用户名  
            String username = "order";  
            // 数据库密码  
            String password = "147258cjj";  
            // 创建Connection连接  
            Connection conn = DriverManager.getConnection(url, username, password); */
			Connection conn= DBUtil.getConnForMySql();
            // 添加图书信息的SQL语句  
            String sql = "UPDATE adminuser SET password=? WHERE userid=?";  
            // 获取Statement  
            PreparedStatement ps = conn.prepareStatement(sql);  
            ps.setString(1, pwd);
            ps.setString(2, user);
            ps.executeUpdate();  
  
            /*List<AdminUser> list = new ArrayList<AdminUser>();  
            while (resultSet.next()) {
            	AdminUser adminuser = new AdminUser();  
            	//user.setId(resultSet.getInt("id"));  
            	adminuser.setId(resultSet.getString("id"));  
            	adminuser.setUserid(resultSet.getString("userid"));  
            	adminuser.setPassword(resultSet.getString("password"));  
                list.add(adminuser);
            }  
            request.setAttribute("list", list);  
            resultSet.close();*/  
            ps.close();  
            conn.close();  
  
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		out.print("<script>alert('修改成功！');window.location='SelectAdminUser'</script>");
        //request.getRequestDispatcher("personal.jsp").forward(request, response);
		//doGet(request, response);
	}

}

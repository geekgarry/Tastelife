/** Automatically generated file. DO NOT MODIFY */
package com.maike.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
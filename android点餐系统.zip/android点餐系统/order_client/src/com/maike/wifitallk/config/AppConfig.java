package com.maike.wifitallk.config;

public class AppConfig
{
	public static final int Port = 8000;
}
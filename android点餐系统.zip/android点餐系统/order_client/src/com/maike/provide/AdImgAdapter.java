package com.maike.provide;

import com.maike.util.OrderDataBaseUtil;
import com.maike.util.OrderStringUtil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class AdImgAdapter {
	/**
	 * ����
	 */
	private String tableName = "adimg";
	
	/**
	 * ����
	 */
	public static final String ID = "_id";
	public static final String CONTENT = "content";
	public static final String IMAGE = "image";
	
	private SQLiteDatabase sdb ;
	private OrderDataBaseUtil orderDB;
	
	public AdImgAdapter(Context context){
		orderDB = new OrderDataBaseUtil(context, tableName, new String[]{CONTENT, IMAGE},
				new String[]{OrderStringUtil.TEXT_NOT_NULL, OrderStringUtil.TEXT_NOT_NULL});
		sdb = orderDB.openWriteDB();
	}
	
	/**
	 * �����ݿ�
	 */
	public void openDB(){
		sdb = orderDB.openWriteDB();
	}
	
	/**
	 * ��
	 */
	public long saveAdImg(String content, String image){
		ContentValues values = new ContentValues();
		
		//values.put(ORDER_ID, orderId);
		values.put(CONTENT, content);
		values.put(IMAGE, image);

		long tag = sdb.insert(tableName, null, values);
		return tag;
		
	}
	
	/**
	 * ɾ
	 */
	/*public int deleteOrder(String orderId){
		return sdb.delete(tableName, ORDER_ID + "=?", new String[]{orderId});
	}*/
	
	/**
	 * ��
	 */
	public int updateAdImg(String content, String image){
		
		ContentValues values = new ContentValues();
		//values.put(NAME, name);
		values.put(CONTENT, content);
		values.put(IMAGE, image);
		
		return sdb.update(tableName, values, CONTENT + "=?", new String[]{content});
		
	}
	
	/**
	 * ��
	 */
	public Cursor queryAdImg(){
		
		Cursor cur = sdb.query(tableName, new String[]{ID, CONTENT, IMAGE},
				null, null, null, null, "create_at desc");
		
		return cur;
	}
	
	/**
	 * �汾���
	 */
	/*public Cursor queryAdImgVersion(){
		Cursor cur = sdb.query(tableName, new String[]{CONTENT, VERSION}, null, null, null, null, null);
		return cur;
	}*/
	
	
	/**
	 * ���ղ˵���ID����ѯ���ݿ�
	 * @param type
	 * @return Cursor
	 */
	public Cursor queryOrderListById(String _id){
		Cursor cursor = sdb.query(tableName, new String[]{ID, CONTENT, IMAGE}, ID+"=?", new String[]{_id}, null, null, null);
		return cursor;
	}
	
	/**
	 * �ر����ݿ�
	 */
	public void closeDB(Cursor cursor) {
		if(null != cursor && !cursor.isClosed())
			cursor.close();
		closeDB();
	}
	
	/**
	 * �ر����ݿ�
	 */
	public void closeDB() {
		if(null != sdb && sdb.isOpen())
			sdb.close();
	}

}

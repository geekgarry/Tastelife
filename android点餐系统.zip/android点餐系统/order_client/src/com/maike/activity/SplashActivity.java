package com.maike.activity;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.maike.application.MyApplication;
import com.maike.bean.Advertise;
import com.maike.util.OrderHttpUtil;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.Toast;

public class SplashActivity extends Activity {
	  //延迟3秒
	  private static final long SPLASH_DELAY_MILLIS = 3000;
	  private boolean tag = true ;
	    //总时间
	  private int totalTime = 0 ;
	  private List<String> imageurls=new ArrayList<String>();
	  private List<String> titles=new ArrayList<String>();
	  private String tag1="TAG_DEMO";
	  private ImageView splash;
	  //网络启动画
	  private String imageString;
	  String responsemsg;
	  Handler hander;
	  String key;
    
	  /**
	   * Handler:跳转到不同界面
	   */
	  private Handler mHandler = new Handler() {
		  @Override
		  public void handleMessage(Message msg) {
			  switch (msg.what) {
			  case 1 :
				  totalTime = totalTime + 200 ;

				  if( totalTime == 3000 ){  //如果总时间大于3秒，就跳转到MainActivity,并且结束计数线程
					  tag = false ;
					  startActivity( new Intent( SplashActivity.this , OrderMainActivity.class ));
					  finish() ;
				  }
				  break ;
			  }
			  super.handleMessage(msg);
		  }
	  };
	protected static final int SHOW_RESPONSE=0;
	protected Handler mhandler;
	  @Override
	  protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    requestWindowFeature(Window.FEATURE_NO_TITLE);
	    setContentView(R.layout.splash);
	    // 使用Handler的postDelayed方法，3秒后执行跳转到MainActivity
	    init();
        query();
        //用于处理和发送消息的Hander
	    mhandler=new Handler(){

			public void handleMessage(Message msg){
	            //如果返现msg.what=SHOW_RESPONSE，则进行制定操作，如想进行其他操作，则在子线程里将SHOW_RESPONSE改变
				super.handleMessage(msg);
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                	try {
	                    responsemsg=(String)msg.obj;
	                    //进行UI操作，将结果显示到界面上
	                    Log.v(tag1,responsemsg);
	                    //Log.v(tag1,responsemsg);
	            		Type listType=new TypeToken<List<Advertise>>(){}.getType();

	            		Gson gson=new Gson();
	            		
	            		List<Advertise> list=gson.fromJson(responsemsg, listType);//result就是从servlet端传过来的字符串
	            	    // 判断集合是否有效  
	            	    if (list == null || list.size() < 1) {  
	            	        System.out.print("没有数据！");
	            	        //runOnUiThread(tsthread);
							Toast.makeText(SplashActivity.this, "网络错误！", Toast.LENGTH_SHORT).show();
	            	    } else {
	            	    	//images = new ArrayList<ImageView>();
	            	        // 遍历图书集合中的数据 
	            	        for (Advertise advertise : list) {
	            	        	//Toast.makeText(this, advertise.getId()+advertise.getContent()+advertise.getImage(), Toast.LENGTH_SHORT).show();
	            	        	//advertise.getId();
	            	        	Log.v(tag1,advertise.getContent());
	            	        	titles.add(advertise.getContent());
	            	        	//advertise.getImage();
	            	        	imageurls.add(OrderHttpUtil.BASE_URL+advertise.getImage());
	            	        	//imageView1 = new ImageView(this);
	            	        	imageString=imageurls.get(0);
	            	        }
	            	     }
	                	}catch (Exception e) {
							// TODO: handle exception
	                		e.printStackTrace();
						}
	            	    runOnUiThread(new Runnable() {  
	                        public void run() {
	            		    //imageLoader.init(ImageLoaderConfiguration.createDefault(SplashActivity.this));
	            	        ImageLoader.getInstance().loadImage( imageString, MyApplication.options , new SimpleImageLoadingListener(){
	            	            @SuppressLint("NewApi") @Override
	            	            public void onLoadingComplete(String imageUri, View view,
	            	                    Bitmap loadedImage) {
	            	                if( totalTime <= 800 ){   //如果在800毫秒内把网络图片加载出来就显示，否则就只显示本地的
	            	                    Drawable drawable = new BitmapDrawable( SplashActivity.this.getResources(), loadedImage );
	            	                    splash.setBackground(drawable);
	            	                }else {
	            	                	splash.setBackgroundColor(R.drawable.splash);
	            	                }
	            	            }
	            	        });
	                        }
	            	    });
	            	    //启动记时工具
	                    new Thread(new ThreadShow()).start();
	                    break;
	            	}
	        	}
	        };
        
	  }
	  private void init() {
		// TODO Auto-generated method stub
		splash=(ImageView)findViewById(R.id.splash);
	  }
	/*private void goHome() {
	    Intent intent = new Intent(SplashActivity.this, OrderMainActivity.class);
	    SplashActivity.this.startActivity(intent);
	    SplashActivity.this.finish();
	  }*/
	  /*public static Bitmap getBitmapFromServer(String imagePath) {  
	      
		    HttpGet get = new HttpGet(imagePath);  
		    HttpClient client = new DefaultHttpClient();  
		    Bitmap pic = null;
		    Drawable d = null;
		    try {  
		        HttpResponse response = client.execute(get);  
		        HttpEntity entity = response.getEntity();  
		        InputStream is = entity.getContent();  
		        //d = Drawable.createFromStream(is, "background.jpg"); 
		        pic = BitmapFactory.decodeStream(is);   // 关键是这句代码  
		          
		    } catch (ClientProtocolException e) {  
		        e.printStackTrace();  
		    } catch (IOException e) {  
		        e.printStackTrace();  
		    }  
		    return pic;  
		}*/
	  /**
	     * 线程类
	     * @author admin
	     * 计时器
	     */
	    class ThreadShow implements Runnable {
	        @Override
	        public void run() {
	            while ( tag ) {
	                try {
	                    Thread.sleep( 200 ); //每间隔200毫秒发送一次
	                    Message msg = new Message();
	                    msg.what = 1 ;
	                    mHandler.sendMessage(msg);
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	    private void query(){
			//开启线程来发起网络请求
	        new Thread(new Runnable() {
	            @Override
	            public void run() {
				String msg=null;
				// url
				String url = OrderHttpUtil.BASE_URL+"BeginImageServlet";
				msg= OrderHttpUtil.dohttppost(url);
				Message message=new Message();
	            message.what=SHOW_RESPONSE;
	            //将服务器返回的数据存放到Message中
	            message.obj=msg;
	            mhandler.sendMessage(message);
	            }
	        }).start();
	    }
}

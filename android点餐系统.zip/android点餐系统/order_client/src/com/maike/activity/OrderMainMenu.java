package com.maike.activity;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.eclipse.jdt.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.maike.application.MyApplication;
import com.maike.bean.Advertise;
import com.maike.provide.OrderAdapter;
import com.maike.util.CalendarUtil;
import com.maike.util.OrderHttpUtil;
import com.maike.util.OrderStringUtil;
import com.maike.util.OrderUrlUtil;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageSize;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class OrderMainMenu extends Fragment {
	
	/**
	 * ������
	 */
	private String str;
	private OrderAdapter dbAdapter;
	
	private String result;
	
	private ProgressDialog proDlg;
	
	private TextView textInfor;
	
	/**
	 * ��ǰ�˵���Ϣ����ʽΪ��orderId-version,orderId-version ...
	 */
	private String data;
	
	/**
	 * ��˰�ť
	 */
	private ImageButton menu_dc;
	//private LinearLayout more_ll;
	private ImageButton menu_sc;
	private ImageButton menu_gx;
	
	//private ImageButton menu_test;
	private ImageButton menu_video;
	private ImageButton menu_tq;
	private ImageButton menu_rl;

	private ImageButton menu_bw;
	private ImageButton order_query;
	private ImageButton menu_tc;
	
	private ViewPager mViewPaper;
	private List<ImageView> images;
	private List<View> dots;
	private int currentItem;
	//��¼��һ�ε��λ��
	private int oldPosition = 0;
	//���ͼƬ��id
	private int[] imageIds = new int[]{
			R.drawable.firstad,
			R.drawable.secondad,
			R.drawable.thirdad,
			R.drawable.fourthad,
			R.drawable.fifthad
	};
	private List<String> imageurls=new ArrayList<String>();
	//���ͼƬ�ı���
	/*private String[]  titles = new String[5];{
        	"���������ף��ҾͲ��ܵ���",	
        	"�����ֻ��������ٳ������ϸ������˴�ϳ�",	
        	"���ر�����Ӱ�������",	
        	"������TV�������",	
        	"��Ѫ��˿�ķ�ɱ"
        };*/
	private List<String> titles=new ArrayList<String>();
	private TextView title;
	private ViewPagerAdapter adapter;
	private ScheduledExecutorService scheduledExecutorService;
	private String tag="LogDemo";
	String imageurl;
	ImageView imageView1;
	int i;
	protected static final int SHOW_RESPONSE=0;
	protected Handler mhandler;
	String responsemsg;
	private ImageButton menu_picture;
	
	public OrderMainMenu() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
	    View view= inflater.inflate(R.layout.order_main, container, false);
	    //requestWindowFeature(featureNoTitle);
		//str = OrderStringUtil.getDataFromIntent(getIntent());
	    return view;
	}
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		
		super.onActivityCreated(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		//setContentView(R.layout.order_main);
		
		/**
		 * ��ʼ�����
		 */
		findView();
		
		/**
		 * ���������Ӱ�ť�¼�
		 */
		setMainButtonListener();
		mViewPaper = (ViewPager) getActivity().findViewById(R.id.vp);
		textInfor = (TextView)getActivity().findViewById(R.id.infor_text);
		str = OrderStringUtil.getDataFromIntent(getActivity().getIntent());
		
		/**
		 * str �ǵ�½�ĳɹ�����
		 * �����ʽΪ id,loginid,password,nikename,create_at
		 */
		String strs[] = str.split(",");
		StringBuilder buf = new StringBuilder();

		buf.append("��ӭ�����ֻ����ϵͳ,���ǽ��߳�Ϊ������.")
			.append("\n\n");
		
		buf.append("��ӭ����");
		if("�ǳ�".equals(strs[3]))
			buf.append(strs[1]).append("\n");
		else
			buf.append(strs[3]).append("\n");
		
		CalendarUtil cu = new CalendarUtil();
		String chineseMonth = cu.getChineseMonth(Integer.parseInt(OrderStringUtil.getCurrentDate("yyyy")),
				Integer.parseInt(OrderStringUtil.getCurrentDate("MM")), Integer.parseInt(OrderStringUtil.getCurrentDate("dd")));
		String chineseDay = cu.getChineseDay(Integer.parseInt(OrderStringUtil.getCurrentDate("yyyy")),
				Integer.parseInt(OrderStringUtil.getCurrentDate("MM")), Integer.parseInt(OrderStringUtil.getCurrentDate("dd")));
		buf.append("�����ǣ�").append(OrderStringUtil.getCurrentDate("yyyy��MM��dd��"));
		buf.append("\nũ����").append(chineseMonth).append(chineseDay);
		
		textInfor.setText(buf.toString());
		query();
		//���ڴ����ͷ�����Ϣ��Hander
	    mhandler=new Handler(){
	        public void handleMessage(Message msg){
	            //�������msg.what=SHOW_RESPONSE��������ƶ�������������������������������߳��ｫSHOW_RESPONSE�ı�
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                    responsemsg=(String)msg.obj;
	                    //����UI�������������ʾ��������
	                    Log.v(tag,responsemsg);
	                    Type listType=new TypeToken<List<Advertise>>(){}.getType();

	            		Gson gson=new Gson();

	            		List<Advertise> list=gson.fromJson(responsemsg, listType);//result���Ǵ�servlet�˴��������ַ���
	            		// ��ȡͼ����Ϣ����  
	            	    //List<Advertise> list = (List<Advertise>)responsemsg;
	            	    // �жϼ����Ƿ���Ч  
	            	    if (list == null || list.size() < 1) {  
	            	        System.out.print("û�����ݣ�");
	            	        Toast.makeText(getActivity(), "���������ݴ���û�����ݣ�", Toast.LENGTH_SHORT).show();
	            	    } else {
	            	    	//images = new ArrayList<ImageView>();
	            	        // ����ͼ�鼯���е�����  
	            	    	
	            	        for (Advertise advertise : list) {
	            	        	//Toast.makeText(this, advertise.getId()+advertise.getContent()+advertise.getImage(), Toast.LENGTH_SHORT).show();
	            	        	//advertise.getId();
	            	        	Log.v(tag,advertise.getContent());
	            	        	titles.add(advertise.getContent());
	            	        	//advertise.getImage();
	            	        	imageurls.add(OrderHttpUtil.BASE_URL+advertise.getImage());
	            	        	//imageView1 = new ImageView(this);
	            	        	}
	            	        }
	            	    	
	            	    		/*images = new ArrayList<ImageView>();
	            	    		imageView1 = new ImageView(this);
	            	    		imageView2 = new ImageView(this);
	            	    		imageView3 = new ImageView(this);
	            	    		imageView4 = new ImageView(this);
	            	    		imageView5 = new ImageView(this);
	            	    		ImageLoader.getInstance().displayImage(imageurls.get(0),imageView1, MyApplication.options);
	            	    		ImageLoader.getInstance().displayImage(imageurls.get(1),imageView2, MyApplication.options);
	            	    		ImageLoader.getInstance().displayImage(imageurls.get(2),imageView3, MyApplication.options);
	            	    		ImageLoader.getInstance().displayImage(imageurls.get(3),imageView4, MyApplication.options);
	            	    		ImageLoader.getInstance().displayImage(imageurls.get(4),imageView5, MyApplication.options);*/
	            	    		
	            	    		/*images.add(imageView1);
	            		        images.add(imageView2);
	            		        images.add(imageView3);
	            		        images.add(imageView4);
	            		        images.add(imageView5);*/
	            				//��ʾ��ͼƬ
	            		        images=new ArrayList<ImageView>();
	            				for(i = 0; i < imageurls.size(); i++){
	            					imageView1 = new ImageView(getActivity());
	            					final String imgurl=imageurls.get(i);
	            					//Drawable drawable = new BitmapDrawable( SplashActivity.this.getResources(), loadedImage );
	            					ImageSize targetSize = new ImageSize(440, 200); // result Bitmap will be fit to this size
	            					ImageLoader.getInstance().displayImage(imgurl,imageView1, MyApplication.options);
	            					//imageView1.setBackgroundResource(tempimg.get(i));
	            					images.add(imageView1);
	            				}
	                        
	            				//��ʾ��С��
	            				dots = new ArrayList<View>();
	            				dots.add(getActivity().findViewById(R.id.dot_0));
	            				dots.add(getActivity().findViewById(R.id.dot_1));
	            				dots.add(getActivity().findViewById(R.id.dot_2));
	            				dots.add(getActivity().findViewById(R.id.dot_3));
	            				dots.add(getActivity().findViewById(R.id.dot_4));
	            				
	            				title = (TextView) getActivity().findViewById(R.id.title);
	            				title.setText(titles.get(0));
	            				
	            				adapter = new ViewPagerAdapter();
	            				mViewPaper.setAdapter(adapter);
	            				
	            				mViewPaper.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
	            					

	            					@Override
	            					public void onPageSelected(int position) {
	            						title.setText(titles.get(position));//[position]);
	            						dots.get(position).setBackgroundResource(R.drawable.dot_focused);
	            						dots.get(oldPosition).setBackgroundResource(R.drawable.dot_normal);
	            						
	            						oldPosition = position;
	            						currentItem = position;
	            					}
	            					
	            					@Override
	            					public void onPageScrolled(int arg0, float arg1, int arg2) {
	            						
	            					}
	            					
	            					@Override
	            					public void onPageScrollStateChanged(int arg0) {
	            						
	            					}
	            				});
	                    break;
	            	}
	        	}
	        };
	}
	/*public static Bitmap getBitmapFromServer(String imagePath) {  
	      
	    HttpGet get = new HttpGet(imagePath);  
	    HttpClient client = new DefaultHttpClient();  
	    Bitmap pic = null;  
	    try {  
	        HttpResponse response = client.execute(get);  
	        HttpEntity entity = response.getEntity();  
	        InputStream is = entity.getContent();  
	          
	        pic = BitmapFactory.decodeStream(is);   // �ؼ���������  
	          
	    } catch (ClientProtocolException e) {  
	        e.printStackTrace();  
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    }  
	    return pic;  
	}*/
	private void query(){
		//�����߳���������������
        new Thread(new Runnable() {
            @Override
            public void run() {
			String msg=null;
			// url
			String url = OrderHttpUtil.BASE_URL+"AdImgServlet";
			msg= OrderHttpUtil.dohttppost(url);
			Message message=new Message();
            message.what=SHOW_RESPONSE;
            //�����������ص����ݴ�ŵ�Message��
            message.obj=msg;
            mhandler.sendMessage(message);
            }
        }).start();
    }
	/**
	 * ���������Ӱ�ť�¼�
	 */
	private void setMainButtonListener() {
		
		menu_dc.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				proDlg = OrderStringUtil.createProgressDialog(getActivity(), getResources().getString(R.string.pro_title), 
						getResources().getString(R.string.pro_message), true, false);
				
				proDlg.show();
				
				new Thread(){
					private String result;

					@Override
					public void run() {

						result = checkOrderVersion();
						
						Message m = new Message();				
						
						if("exception".equals(result))
							m.what = OrderStringUtil.SERVER_ERROR;
						else if("error".equals(result))
							m.what = OrderStringUtil.SERVER_NO_DATA;
						else if(result.split(",").length == 4)
							m.what = OrderStringUtil.DATA_DETAIL;
						else if("010010101101110101000100".equals(result))
							m.what = OrderStringUtil.GO_ORDER;
						else 
							m.what = OrderStringUtil.ERROR;
						
						handler.sendMessage(m);
					}
				}.start();
			}
		});
		/**
		 * �˵�����
		 */
		menu_gx.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				
				proDlg = OrderStringUtil.createProgressDialog(getActivity(), getResources().getString(R.string.pro_title), 
						getResources().getString(R.string.pro_message), true, false);
				
				proDlg.show();
				
				new Thread(){
					@Override
					public void run() {
						/**
						 * exception Ϊ����������
						 *  ��   ��      ɾ    ��
						 * new,update,delete,error
						 * 010010101101110101000100 ���
						 */
						result = checkOrderVersion();
						
						Message m = new Message();
						
						if("exception".equals(result))
							m.what = OrderStringUtil.SERVER_ERROR;							
						else if("010010101101110101000100".equals(result))
							m.what = OrderStringUtil.OK;
						else if(result.split(",").length == 4)
							m.what = OrderStringUtil.DATA_DETAIL;
						else 
							m.what = OrderStringUtil.ERROR;
						
						handler.sendMessage(m);
					}
				}.start();
			}
		});
		/**
		 * ����
		 */
		menu_picture.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getActivity(), SpiderImgs.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
			}
		});
		/**
		 * ������Ƶ
		 */
		menu_video.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				Intent i = new Intent(getActivity(), OrderAmusementActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				OrderStringUtil.putDataIntoIntent(i, str);
				startActivity(i);
			}
		});
		/**
		 * ����¼
		 */
		menu_bw.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				Intent i = new Intent(getActivity(), OrderNoteActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				OrderStringUtil.putDataIntoIntent(i, str);
				startActivity(i);
			}
		});
		
		/**
		 * ����Ԥ��
		 */
		menu_tq.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), OrderWeather.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				Bundle b = new Bundle();
				b.putString("data", str);
				intent.putExtra("data", b);
				startActivity(intent);
			}
		});
		/**
		 * �˵���ѯ
		 */
		order_query.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				Intent intent = new Intent(getActivity(), OrderAllActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		
		/**
		 * ��������
		 */
		menu_rl.setOnClickListener(new ImageButton.OnClickListener() {
			
			public void onClick(View v) {
				Intent i = new Intent(getActivity(), OrderCalendarActivity.class);
				i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				OrderStringUtil.putDataIntoIntent(i, str);
				startActivity(i);
			}
		});
		
	}

	/**
	 * ʵ�������
	 */
	private void findView() {
		menu_dc = (ImageButton)getActivity().findViewById(R.id.menu_diancang);
		//menu_dc.setBackgroundResource(0);
		menu_video = (ImageButton)getActivity().findViewById(R.id.vidoe);
		//menu_yl.setBackgroundResource(0);
		menu_gx = (ImageButton)getActivity().findViewById(R.id.menu_gx);
		//menu_gx.setBackgroundResource(0);
		menu_rl = (ImageButton)getActivity().findViewById(R.id.menu_rl);
		//menu_rl.setBackgroundResource(0);
		menu_tq = (ImageButton)getActivity().findViewById(R.id.menu_tq);
		//menu_tq.setBackgroundResource(0);
		menu_picture = (ImageButton)getActivity().findViewById(R.id.menu_goodpicture);
		//menu_test.setBackgroundResource(0);
		menu_bw= (ImageButton)getActivity().findViewById(R.id.menu_bw);
		order_query= (ImageButton)getActivity().findViewById(R.id.order_query);
		
	}
	
	private String checkOrderVersion(){
		dbAdapter = new OrderAdapter(getActivity());
		/**
		 *  ������
		 *  ���߱���������Ϣ����װ�ַ�����������������
		 *  ���������������ݣ����ظ��½����״̬
		 */

		Cursor cursor = dbAdapter.queryOrderVersion();
		
		StringBuilder buf = new StringBuilder();
		if(cursor.moveToFirst()){
			do{
				/**
				 * �õ�ID
				 */
				int idIndex = cursor.getColumnIndex(OrderAdapter.ORDER_ID);
				String id = cursor.getString(idIndex);
				buf.append(id).append("-");
				/**
				 * �õ��汾
				 */
				int versionIndex = cursor.getColumnIndex(OrderAdapter.VERSION);
				String version = cursor.getString(versionIndex);
				buf.append(version).append(",");
				
				cursor.moveToNext();
			}while(!cursor.isAfterLast());
		}
		
		dbAdapter.closeDB();
		data = buf.toString();
		
		if(data.length() > 0)
			data = data.substring(0, data.length()-1);
		
		String queryString = "data=" + data;
		String url = OrderHttpUtil.BASE_URL + OrderUrlUtil.CHECK_ORDER_VERSION + queryString;
		
		String result = null;
		result = OrderHttpUtil.dohttppost(url);
		return result;
	}
	
	// ��Ϣ����
	Handler handler = new Handler(){
		@Override
		public void dispatchMessage(Message msg) {
			
			AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
			proDlg.dismiss();
			switch (msg.what){
			case OrderStringUtil.SERVER_ERROR:
				builder.setTitle("����������")
					.setIcon(R.drawable.alert_wanring)
					.setMessage("�������������Ժ����ԣ�")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
						}
					}).show();
				break;
			case OrderStringUtil.SERVER_NO_DATA:
				builder.setTitle("������")
					.setIcon(R.drawable.alert_error)
					.setMessage("���������ݣ����ܵ�ˣ�")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
						}
					}).show();
				break;
			case OrderStringUtil.DATA_DETAIL:
				final String r[] = result.split(",");
				builder.setTitle("ͬ���˵�")
					.setIcon(R.drawable.alert_ok)
					.setMessage("����Ҫ��������\n ������" + r[0] + "\t���£�" + r[1] + "\n ɾ����" + r[2] + "\t����" + r[3])
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Log.i("UPDATE_TAG", "udpate_data");
							// code update order ���²˵���
							
							Bundle bundle = new Bundle();
							bundle.putString("new", r[0]);
							bundle.putString("update", r[1]);
							bundle.putString("delete", r[2]);
							bundle.putString("error", r[3]);
							bundle.putString("data", data);

							Intent intent = new Intent(getActivity(), OrderUpdateActivity.class);
							intent.putExtra("data", bundle);
							startActivity(intent);
						}
					}).setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {}
					}).show();
				break;
			case OrderStringUtil.GO_ORDER:
				/**
				 * ���
				 */
				Intent intent = new Intent(getActivity(), OrderListActivity.class);				
				OrderStringUtil.putDataIntoIntent(intent, str);				
				startActivity(intent);
				break;
			case OrderStringUtil.ERROR :
				builder.setTitle("����")
					.setIcon(R.drawable.alert_error)
					.setMessage("���������ԣ�����")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Log.i("UPDATE_TAG", "udpate_data");
						}
					}).show();
				break;
			case OrderStringUtil.OK:
				builder.setTitle("���ݲ���Ҫ����")
					.setIcon(R.drawable.alert_wanring)
					.setMessage("���ݲ���Ҫ���£�������ֱ�ӵ��")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Intent intent = new Intent();
							intent.setClass(getActivity(), OrderListActivity.class);
							OrderStringUtil.putDataIntoIntent(intent, str);
							startActivity(intent);
						}
					}).show();
				break;
			}
		}
	};
	/**
	 * �Զ���Adapter
	 * @author liuyazhuang
	 *
	 */
	private class ViewPagerAdapter extends PagerAdapter{

		@Override
		public int getCount() {
			return images.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}

		@Override
		public void destroyItem(ViewGroup view, int position, Object object) {
			// TODO Auto-generated method stub
//			super.destroyItem(container, position, object);
//			view.removeView(view.getChildAt(position));
//			view.removeViewAt(position);
			view.removeView(images.get(position));
		}

		@Override
		public Object instantiateItem(ViewGroup view, int position) {
			// TODO Auto-generated method stub
			view.addView(images.get(position));
			return images.get(position);
		}
		
	}
	
	/*public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}*/

	/**
	 * �����̳߳ض�ʱִ�ж����ֲ�
	 */
	@Override
	public void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		scheduledExecutorService.scheduleWithFixedDelay(new ViewPageTask(), 3, 3, TimeUnit.SECONDS);
	}
	
	
	private class ViewPageTask implements Runnable{

		@Override
		public void run() {
			currentItem = (currentItem + 1) % imageurls.size();//imageIds.length;
			mHandler.sendEmptyMessage(0);
		}
	}
	
	/**
	 * �������̴߳��ݹ���������
	 */
	private Handler mHandler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			mViewPaper.setCurrentItem(currentItem);
		};
	};
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
}

package com.maike.activity;

import java.util.ArrayList;

import org.eclipse.jdt.annotation.Nullable;

import com.maike.activity.MenuPagerActivity.Extra;
import com.maike.provide.OrderAdapter;
import com.maike.util.OrderHttpUtil;
import com.maike.util.OrderStringUtil;
import com.maike.util.OrderUrlUtil;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PerfileFragment extends Fragment  implements OnClickListener{
	private LinearLayout menu_favourite;
	private LinearLayout menu_update_order;
	private LinearLayout menu_perfile;
	private LinearLayout menu_user;
	private LinearLayout menu_logout;
	private String str;
	private TextView loginuser;
	private TextView id_no;
	private ProgressDialog proDlg;
	private String result;
	private OrderAdapter dbAdapter;
	/**
	 * ��ǰ�˵���Ϣ����ʽΪ��orderId-version,orderId-version ...
	 */
	private String data;
	String username;
	@Override
	public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState) {
	    return inflater.inflate(R.layout.perfilefragment, container, false);
	}
	public void onActivityCreated(Bundle savedInstanceState) {
			
			super.onActivityCreated(savedInstanceState);
			/**
			 * ��ʼ�����
			 */
			findView();
			loginuser=(TextView)getActivity().findViewById(R.id.loginuser);
			id_no=(TextView)getActivity().findViewById(R.id.id_no);
			str = OrderStringUtil.getDataFromIntent(getActivity().getIntent());
			/**
			 * str �ǵ�½�ĳɹ�����
			 * �����ʽΪ id,loginid,password,nikename,create_at
			 */
			String strs[] = str.split(",");
			StringBuilder buf = new StringBuilder();
			StringBuilder bufid = new StringBuilder();
			/*buf.append("��ӭ�����ֻ����ϵͳ,���ǽ��߳�Ϊ������.")
				.append("\n\n");
			
			buf.append("��ӭ����");*/
			if("�ǳ�".equals(strs[3])) {
				buf.append(strs[1]).append("\n");
			}
			else {
				buf.append(strs[3]).append("\n");
				bufid.append(strs[0]).append("\n");
			}
			Bundle bundle = getActivity().getIntent().getExtras();
			username = bundle.getString("username");
			loginuser.setText(buf.toString());
			id_no.setText("��ζ��:"+bufid);
		}
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.menu_favourite:
			Intent favourite = new Intent(getActivity(), OrderCollectActivity.class);
			favourite.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			OrderStringUtil.putDataIntoIntent(favourite, str);
			startActivity(favourite);
			break;
		case R.id.order_log:
			Intent order_log = new Intent(getActivity(), OrderLogActivity.class);
			order_log.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			//OrderStringUtil.putDataIntoIntent(order_log, str);
			order_log.putExtra("username", username);
			startActivity(order_log);
			break;
		case R.id.menu_perfile:
			Intent perfile = new Intent(getActivity(), InforModifyActivity.class);
			perfile.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			OrderStringUtil.putDataIntoIntent(perfile, str);
			startActivity(perfile);
			break;
		case R.id.menu_user:
			Intent usersetting = new Intent(getActivity(), OrderSettingActivity.class);
			usersetting.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			OrderStringUtil.putDataIntoIntent(usersetting, str);
			startActivity(usersetting);
			break;
		case R.id.menu_logout:
			Intent logout = new Intent(getActivity(), OrderMainActivity.class);
			logout.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(logout);
			break;
		default:
            break;
		}
	}
	private void findView() {
		// TODO Auto-generated method stub
		menu_favourite = (LinearLayout)getActivity().findViewById(R.id.menu_favourite);
		menu_favourite.setOnClickListener(this);
		menu_update_order=(LinearLayout)getActivity().findViewById(R.id.order_log);
		menu_update_order.setOnClickListener(this);
		menu_perfile=(LinearLayout)getActivity().findViewById(R.id.menu_perfile);
		menu_perfile.setOnClickListener(this);
		menu_user=(LinearLayout)getActivity().findViewById(R.id.menu_user);
		menu_user.setOnClickListener(this);
		menu_logout=(LinearLayout)getActivity().findViewById(R.id.menu_logout);
		menu_logout.setOnClickListener(this);
	}
	/*private String checkOrderVersion(){
		dbAdapter = new OrderAdapter(getActivity());
		*//**
		 *  ������
		 *  ���߱���������Ϣ����װ�ַ�����������������
		 *  ���������������ݣ����ظ��½����״̬
		 *//*

		Cursor cursor = dbAdapter.queryOrderVersion();
		
		StringBuilder buf = new StringBuilder();
		if(cursor.moveToFirst()){
			do{
				*//**
				 * �õ�ID
				 *//*
				int idIndex = cursor.getColumnIndex(OrderAdapter.ORDER_ID);
				String id = cursor.getString(idIndex);
				buf.append(id).append("-");
				*//**
				 * �õ��汾
				 *//*
				int versionIndex = cursor.getColumnIndex(OrderAdapter.VERSION);
				String version = cursor.getString(versionIndex);
				buf.append(version).append(",");
				
				cursor.moveToNext();
			}while(!cursor.isAfterLast());
		}
		
		dbAdapter.closeDB();
		data = buf.toString();
		
		if(data.length() > 0)
			data = data.substring(0, data.length()-1);
		
		String queryString = "data=" + data;
		String url = OrderHttpUtil.BASE_URL + OrderUrlUtil.CHECK_ORDER_VERSION + queryString;
		
		String result = null;
		result = OrderHttpUtil.dohttppost(url);
		return result;
	}*/

}

package com.maike.activity;

import org.eclipse.jdt.annotation.Nullable;

import com.maike.util.OrderStringUtil;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;

public class FindFragment extends Fragment  implements OnClickListener{
	private LinearLayout menu_pictrue;
	private LinearLayout menu_wifi_talk;
	private LinearLayout menu_game;
	private LinearLayout menu_weather;
	LinearLayout menu_taste;
	private String str;
	@Override
	public View onCreateView(LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState) {
	    return inflater.inflate(R.layout.findfragment, container, false);
	}
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		
		super.onActivityCreated(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		//setContentView(R.layout.order_main);
		str = OrderStringUtil.getDataFromIntent(getActivity().getIntent());
		/**
		 * ��ʼ�����
		 */
		findView();
		
	}
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.menu_picture:
			Intent i = new Intent(getActivity(), AllPictureActivity.class);
			i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i);
			break;
		case R.id.menu_weather:
			Intent intent = new Intent(getActivity(), OrderWeather.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			Bundle b = new Bundle();
			b.putString("data", str);
			intent.putExtra("data", b);
			startActivity(intent);
			break;
		case R.id.menu_game:
			Intent game = new Intent(getActivity(), Piano.class);
			game.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(game);
			break;
		case R.id.menu_wifi_talk:
			Intent wifitalk = new Intent(getActivity(), WifiTallk.class);
			wifitalk.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(wifitalk);
			break;
		case R.id.menu_taste:
			Intent taste = new Intent(getActivity(), FoodCircle.class);
			taste.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(taste);
			break;
		default:
            break;
		}
	}
	private void findView() {
		// TODO Auto-generated method stub
		menu_pictrue = (LinearLayout)getActivity().findViewById(R.id.menu_picture);
		menu_pictrue.setOnClickListener(this);
		menu_weather=(LinearLayout)getActivity().findViewById(R.id.menu_weather);
		menu_weather.setOnClickListener(this);
		menu_game=(LinearLayout)getActivity().findViewById(R.id.menu_game);
		menu_game.setOnClickListener(this);
		menu_wifi_talk=(LinearLayout)getActivity().findViewById(R.id.menu_wifi_talk);
		menu_wifi_talk.setOnClickListener(this);
		menu_taste=(LinearLayout)getActivity().findViewById(R.id.menu_taste);
		menu_taste.setOnClickListener(this);
	}
}

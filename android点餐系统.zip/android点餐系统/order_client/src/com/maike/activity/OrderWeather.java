package com.maike.activity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.maike.bean.WeatherBean;
import com.maike.util.Week;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

@SuppressLint("HandlerLeak")
public class OrderWeather extends Activity implements OnClickListener {

	// ���
	private TextView textView_title_city, textView_title_pm;
	private TextView textView_main_weather, textView_main_wind, textView_main_date, textView_main_temp;
	private ImageButton imageButton_refresh, imageButton_search;

	private LinearLayout other_weatehr;

	// ����
	private Handler handler;

	public List<WeatherBean> list;

	public SharedPreferences sharedPreferences;

	private int codeInt = 101071401; // ���յ��ĳ���id

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.weather_all);

		// 1. ������ȡ��ѡ��ʵ��
		sharedPreferences = getSharedPreferences("myWeather", MODE_PRIVATE);
		codeInt = sharedPreferences.getInt("codeInt", 101120504);

		initView();

		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				if (msg.what == 1) {
					// System.out.println("�����Ϣ");
					// ���½���
					imageButton_refresh.setImageResource(R.drawable.refresh);

					// System.out.println(list.toString());
					if (list != null && list.size() == 6) {
						other_weatehr.removeAllViews();
						for (int i = 0; i < 6; i++) {
							WeatherBean bean = list.get(i);
							if (i == 0) {
								// ��һ��
								textView_title_city.setText(bean.getCity());
								textView_title_pm.setText("PM:" + bean.getPm());
								textView_main_date.setText(bean.getDate_y());
								textView_main_temp.setText(bean.getTempCurrent() + "��C");
								textView_main_wind.setText(bean.getWindCurrent());
								textView_main_weather.setText(bean.getWeather() + " " + bean.getTemp());
							} else {

								// δ������
								View itemView = LayoutInflater.from(OrderWeather.this).inflate(R.layout.day_wather,
										null);
								TextView textView_week = (TextView) itemView.findViewById(R.id.textView_week);
								TextView textView_weather = (TextView) itemView.findViewById(R.id.textView_weather);
								TextView textView_temp_range = (TextView) itemView
										.findViewById(R.id.textView_temp_range);

								textView_week.setText(bean.getWeek());
								textView_temp_range.setText(bean.getTemp());
								textView_weather.setText(bean.getWeather());
								other_weatehr.addView(itemView);
							}

						}

					}
				}
			}
		};

		list = new ArrayList<WeatherBean>();
	}

	/**
	 * ��ʼ�����
	 */
	private void initView() {
		textView_title_city = (TextView) findViewById(R.id.textView_title_city);
		textView_title_pm = (TextView) findViewById(R.id.textView_title_pm);
		textView_main_temp = (TextView) findViewById(R.id.textView_main_temp);
		textView_main_weather = (TextView) findViewById(R.id.textView_main_weather);
		textView_main_wind = (TextView) findViewById(R.id.textView_main_wind);
		textView_main_date = (TextView) findViewById(R.id.textView_main_date);

		imageButton_refresh = (ImageButton) findViewById(R.id.imageButton_refresh);
		imageButton_search = (ImageButton) findViewById(R.id.imageButton_search);

		imageButton_refresh.setOnClickListener(this);
		imageButton_search.setOnClickListener(this);

		other_weatehr = (LinearLayout) findViewById(R.id.other_weatehr);

		// ����ʱ�����ť
		imageButton_refresh.performClick();
	}

	/**
	 * ��ȡ��������
	 */
	private void getData(String url) {
		try {
			String result = "";
			HttpGet get = new HttpGet(new URI(url));

			HttpClient conn = new DefaultHttpClient();

			HttpResponse response = conn.execute(get);
			if (response == null) {
				return;
			} else if (response.getStatusLine().getStatusCode() == 200) {
				// �ɹ�
				// 3. ��ȡ��Ϣʵ��
				HttpEntity entity = response.getEntity();
				// 4. ת����
				InputStream inputStream = entity.getContent();
				// 5. ������
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
				String line = "";
				while ((line = reader.readLine()) != null) {
					result += line;
				}
				// Log.i("Request", result);

				// ��ȡ����

				if (result.contains("weather_callback")) {
					result = result.substring(result.indexOf("(") + 1, result.indexOf(")"));
				}

				// ��������
				list = jsonParser(result);

				// ��������
				Message msg = new Message();
				msg.what = 1;
				handler.sendEmptyMessage(msg.what);
				// text_result.setText(result);
				reader.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * �����ж�
	 */
	private boolean isActive() {
		ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = manager.getActiveNetworkInfo();
		if (info == null) {
			return false;
		}

		return true;
	}

	/**
	 * json ���ݽ�������
	 * 
	 * @param jsonString
	 *            json�ַ���
	 * @return
	 */
	private List<WeatherBean> jsonParser(String jsonString) {

		List<WeatherBean> list_weather = new ArrayList<WeatherBean>();
		int week_int = 1;
		String week;

		// 1. �ж��ַ����ǲ�����Ч
		if (TextUtils.isEmpty(jsonString)) {
			return list_weather;
		}

		// 2. ��ʼ�������ݵ� list
		try {
			JSONObject object = new JSONObject(jsonString);
			JSONObject weather_info = object.getJSONObject("weatherinfo");

			for (int i = 1; i < 7; i++) {
				WeatherBean bean = new WeatherBean();

				// ������Ϣ
				if (i == 1) {
					bean.setCity(weather_info.getString("city"));
					bean.setPm(weather_info.getString("pm"));
					bean.setDate_y(weather_info.getString("date_y"));
					bean.setTempCurrent(weather_info.getString("temp"));
					bean.setWindCurrent(weather_info.getString("wd"));
				}

				// ����
				week = weather_info.getString("week");

				week_int = Week.week_int(week);
				week = Week.int_week((week_int + i - 1) % 7);

				// System.out.println("����:" + week);

				// ������Ϣ
				bean.setWeek(week);
				bean.setTemp(weather_info.getString("temp" + i));
				bean.setWeather(weather_info.getString("weather" + i));

				// ���ӵ�list_weather

				list_weather.add(bean);
			}

		} catch (JSONException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

		return list_weather;
	}

	/**
	 * ��ó��н��
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO �Զ����ɵķ������
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 100) { // ���������ת��ȥ��
			// ���صĳ��н��
			if (resultCode == 0) {
				codeInt = sharedPreferences.getInt("codeInt", 101120504);
				return;
			} else {

				codeInt = resultCode;
			}
			
			System.out.println("���صĴ���: " + resultCode);
			System.out.println("��ǰ����: " + codeInt);
			
			Editor editor = sharedPreferences.edit();
			editor.putInt("codeInt", codeInt);
			editor.commit(); // �ύ

			
			// ˢ������
			refreshData();
		}
	}

	/**
	 * ��ť����
	 */
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.imageButton_refresh:
			imageButton_refresh.setImageResource(R.drawable.pb_bg);
			// ((AnimationDrawable)imageButton_refresh.getBackground()).start();
			refreshData();
			break;

		case R.id.imageButton_search:
			Intent intent = new Intent(this, SearchActivity.class);

			startActivityForResult(intent, 100);
			break;

		default:
			break;
		}

	}

	/**
	 * 
	 */
	private void refreshData() {
		new Thread(new Runnable() {

			@Override
			public void run() {
				if (isActive()) {
					String url = "http://weather.123.duba.net/static/weather_info/" + codeInt + ".html";
					// String baidu = "http://www.baidu.com";
					getData(url);
				} else {
					// �����쳣
					Log.i("net", "�쳣");
				}

			}
		}).start();
	}

	// @Override
	// public boolean onCreateOptionsMenu(Menu menu) {
	// // Inflate the menu; this adds items to the action bar if it is present.
	// getMenuInflater().inflate(R.menu.main, menu);
	// return true;
	// }
	//
	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// // Handle action bar item clicks here. The action bar will
	// // automatically handle clicks on the Home/Up button, so long
	// // as you specify a parent activity in AndroidManifest.xml.
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }
}
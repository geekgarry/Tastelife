package com.maike.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

public class VideoOneActivity extends Activity{
	private ArrayList<String> names;
	private ArrayList<String> descriptions;
	private ArrayList<String> videourls;
	//private ArrayList<String> create_dt;
	TextView name;
	TextView description;
	TextView video;
	private VideoView videoView;
	private static final String STATE_POSITION = "STATE_POSITION";

	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.videoone);
		Bundle bundle = getIntent().getExtras();
		names = bundle.getStringArrayList("names");
		descriptions = bundle.getStringArrayList("descrptions");
		videourls = bundle.getStringArrayList("videourls");
		//create_dt = bundle.getStringArrayList("create_dt");
		//��¼ ��ǰͼƬ��λ�á�
		int pagerPosition = bundle.getInt(Extra.IMAGE_POSITION, 0);
		//�����û�֮ǰ������
		if (savedInstanceState != null) {
			pagerPosition = savedInstanceState.getInt(STATE_POSITION);
		}
		name=(TextView)findViewById(R.id.name);
		description=(TextView)findViewById(R.id.description);
		//������Ƶ
        String videoUrl = videourls.get(pagerPosition);
        name.setText(names.get(pagerPosition));
        description.setText(descriptions.get(pagerPosition));
        Uri uri = Uri.parse(videoUrl);

        videoView = (VideoView)this.findViewById(R.id.videoview );

        //������Ƶ������
        videoView.setMediaController(new MediaController(this));

        //������ɻص�
        videoView.setOnCompletionListener( new MyPlayerOnCompletionListener());

        //������Ƶ·��
        videoView.setVideoURI(uri);

        //��ʼ������Ƶ
        videoView.start();
	}
	class MyPlayerOnCompletionListener implements MediaPlayer.OnCompletionListener {

        @Override
        public void onCompletion(MediaPlayer mp) {
            Toast.makeText( VideoOneActivity.this, "���������", Toast.LENGTH_SHORT).show();
        }
    }
}

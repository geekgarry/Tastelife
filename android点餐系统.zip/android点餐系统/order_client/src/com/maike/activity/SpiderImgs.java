package com.maike.activity;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.maike.ImageViewPager.SpiderImagePager;
import com.maike.activity.AllPictureActivity.Extra;
import com.maike.activity.AllPictureActivity.ImageAdapter;
import com.maike.activity.SplashActivity.ThreadShow;
import com.maike.application.MyApplication;
import com.maike.bean.Advertise;
import com.maike.util.OrderHttpUtil;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class SpiderImgs extends Activity{
	private ImageLoader imageLoader;
	private final int SHOW_RESPONSE=0;
	private String responsemsg;
	private Handler mhandler;
	List<String> imageUrls=new ArrayList<String>();
	private int id;
	
	private DisplayImageOptions options;
	String url = "http://www.27270.com/meishitupian/index.html";
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.spiderimgs);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(SpiderImgs.this));
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error)
				.cacheInMemory(true)
				.cacheOnDisc(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.build();
		query();
        //���ڴ����ͷ�����Ϣ��Hander
	    mhandler=new Handler(){

			private String tag1="Spider";

			public void handleMessage(Message msg){
	            //�������msg.what=SHOW_RESPONSE��������ƶ�������������������������������߳��ｫSHOW_RESPONSE�ı�
				super.handleMessage(msg);
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                	try {
	                    responsemsg=(String)msg.obj;
	                    //����UI�������������ʾ��������
	                    Log.v(tag1,responsemsg);
	                    Document document = Jsoup.parse(responsemsg);
	                    
	                    document.setBaseUri(url);
	            		//��ȡ���е�imgԪ��
	            		Elements elements = document.select("img");
	            		for (Element e : elements) {
	            			//��ȡÿ��src�ľ���·��
	            			String src = e.absUrl("src");
	            			//URL urlSource = new URL(src);
	            			//URLConnection urlConnection = urlSource.openConnection();
	            			//String imageName = src.substring(src.lastIndexOf("/") + 1, src.length());
	            			imageUrls.add(src);
	            		}
	            		GridView gridView = (GridView) findViewById(R.id.gridview);
	            		gridView.setAdapter(new ImageAdapter());
	            		gridView.setOnItemClickListener(new OnItemClickListener() {
	            			@Override
	            			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	            				startImagePagerActivity(position);
	            			}
	            		});
	                	}catch (Exception e) {
							// TODO: handle exception
	                		e.printStackTrace();
						}
	                    break;
	            	}
	        	}
	        };
	}
	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	private void startImagePagerActivity(int position) {
		Intent intent = new Intent(this, SpiderImagePager.class);
		intent.putStringArrayListExtra(Extra.IMAGES, (ArrayList<String>) imageUrls);
		intent.putExtra(Extra.IMAGE_POSITION, position);
		startActivity(intent);
	}
	
	
	public class ImageAdapter extends BaseAdapter {
		@Override
		public int getCount() {
			return imageUrls.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final ImageView imageView;
			if (convertView == null) {
				imageView = (ImageView) getLayoutInflater().inflate(R.layout.item_grid_image, parent, false);
			} else {
				imageView = (ImageView) convertView;
			}
			imageLoader.displayImage(imageUrls.get(position), imageView, options);
			return imageView;
		}
	}
	private void query(){
		//�����߳���������������
        new Thread(new Runnable() {

			@Override
            public void run() {
			String msg=null;
			// url
			//String url = "http://www.mmonly.cc/mmtp/list_9_1.html";
			msg= OrderHttpUtil.dohttpget(url);
			Message message=new Message();
            message.what=SHOW_RESPONSE;
            //�����������ص����ݴ�ŵ�Message��
            message.obj=msg;
            mhandler.sendMessage(message);
            }
        }).start();
    }
}

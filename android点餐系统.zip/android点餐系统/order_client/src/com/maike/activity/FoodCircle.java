package com.maike.activity;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.maike.activity.AllPictureActivity.Extra;
import com.maike.activity.AllPictureActivity.ImageAdapter;
import com.maike.util.OrderHttpUtil;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class FoodCircle  extends Activity{
	List<String> imageUrls=new ArrayList<String>();
	List<String> detailurl=new ArrayList<String>();
	List<String> titles=new ArrayList<String>();
	protected ImageLoader imageLoader;
	DisplayImageOptions options;
	private final int SHOW_RESPONSE=0;
	String url = "http://www.27270.com/meishitupian/list_25_1.html";
	private Handler mhandler;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.foodcirclegrid);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(FoodCircle.this));
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error)
				.cacheInMemory(true)
				.cacheOnDisc(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.build();
		query();
		//���ڴ����ͷ�����Ϣ��Hander
	    mhandler=new Handler(){

			private String tag1="Spider";
			private String responsemsg;

			public void handleMessage(Message msg){
	            //�������msg.what=SHOW_RESPONSE��������ƶ�������������������������������߳��ｫSHOW_RESPONSE�ı�
				super.handleMessage(msg);
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                	try {
	                    responsemsg=(String)msg.obj;
	                    //����UI�������������ʾ��������
	                    Log.v(tag1,responsemsg);
	                    Document document = Jsoup.parse(responsemsg);
	                    
	                    document.setBaseUri(url);
	            		//��ȡ���е�imgԪ��
	            		Elements elements = document.select(".wenshen a");
	            		Elements elements1 = document.select(".wenshen img");
	            		for (Element e : elements1) {
	            			//��ȡÿ��src�ľ���·��
	            			//String src = e.absUrl("href");
	            			//String title=e.attr("title");
	            			String imgurl=e.absUrl("src");
	            			//URL urlSource = new URL(src);
	            			//URLConnection urlConnection = urlSource.openConnection();
	            			//String imageName = src.substring(src.lastIndexOf("/") + 1, src.length());
	            			imageUrls.add(imgurl);
	            			//titles.add(title);
	            			//detailurl.add(src);
	            		}
	            		for (Element e : elements) {
	            			//��ȡÿ��src�ľ���·��
	            			String src = e.absUrl("href");
	            			String title=e.attr("title");
	            			String str = new String(title.getBytes("utf-8"), "gb2312"); 
	            			//String imgurl=e.absUrl("src");
	            			//URL urlSource = new URL(src);
	            			//URLConnection urlConnection = urlSource.openConnection();
	            			//String imageName = src.substring(src.lastIndexOf("/") + 1, src.length());
	            			//imageUrls.add(imgurl);
	            			titles.add(str);
	            			detailurl.add(src);
	            		}
	            		GridView gridView = (GridView) findViewById(R.id.gridview);
	            		gridView.setAdapter(new ImageAdapter(FoodCircle.this, imageUrls, titles));
	            		gridView.setOnItemClickListener(new OnItemClickListener() {
	            			@Override
	            			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	            				startImagePagerActivity(position);
	            			}
	            		});
	                	}catch (Exception e) {
							// TODO: handle exception
	                		e.printStackTrace();
						}
	                    break;
	            	}
	        	}
	        };		
	}
	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	private void startImagePagerActivity(int position) {
		Intent intent = new Intent(this, ImagePagerActivity.class);
		intent.putStringArrayListExtra(Extra.IMAGES, (ArrayList<String>) imageUrls);
		intent.putStringArrayListExtra("titles", (ArrayList<String>) titles);
		intent.putStringArrayListExtra("hrefsrc", (ArrayList<String>) detailurl);
		intent.putExtra(Extra.IMAGE_POSITION, position);
		startActivity(intent);
	}
	
	
	public class ImageAdapter extends BaseAdapter {
		
		private LayoutInflater layoutInflater;
		private List<String> titles;
		private List<String> imageurls1;
		public ImageAdapter(FoodCircle act, List<String> imageurls1, List<String> titles) {
			// TODO Auto-generated constructor stub
            this.imageurls1=imageurls1;
            this.titles = titles;
            layoutInflater = LayoutInflater.from(act);
		}
		@Override
		public int getCount() {
			return imageUrls.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = layoutInflater.inflate(R.layout.item_food_image,null);
			final ImageView imageView;
			TextView title = null;
			/*if (convertView == null) {
				imageView = (ImageView) getLayoutInflater().inflate(R.layout.item_grid_image, parent, false);
			} else {
				imageView = (ImageView) convertView;
			}*/
			imageView = (ImageView) v.findViewById(R.id.image);
            title = (TextView) v.findViewById(R.id.title);
			imageLoader.displayImage(imageUrls.get(position), imageView, options);
			title.setText(titles.get(position));
			return v;
		}
	}
	private void query(){
		//�����߳���������������
        new Thread(new Runnable() {

			@Override
            public void run() {
			String msg=null;
			// url
			//String url = "http://www.mmonly.cc/mmtp/list_9_1.html";
			msg= OrderHttpUtil.dohttpget(url);
			Message message=new Message();
            message.what=SHOW_RESPONSE;
            //�����������ص����ݴ�ŵ�Message��
            message.obj=msg;
            mhandler.sendMessage(message);
            }
        }).start();
    }
}

package com.maike.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;

import com.maike.activity.R;
import com.maike.bean.Orders;
import com.maike.provide.OrderAdapter;
import com.maike.util.OrderHttpUtil;
import com.maike.util.OrderStringUtil;
import com.maike.util.OrderUrlUtil;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

public class OrderDetailActivity extends Activity {

	private String id;
	
	private ImageView detail_image;
	private TextView detail_price;
	private TextView detail_name;
	private TextView detail_create;
	private TextView detail_desc;

	private Button make_order;
	private Button collect_order;
	
	private AutoCompleteTextView site_auto_text_number;
	
	private OrderAdapter orderDb;
	
	private Orders o;
	private ProgressDialog proDlg;
	private String str;

	private ImageLoader imageLoader;

	private DisplayImageOptions options;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.order_detail);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(OrderDetailActivity.this));
		str = OrderStringUtil.getDataFromIntent(getIntent());
		id = getIntent().getStringExtra("ID");
		
		proDlg = OrderStringUtil.createProgressDialog(this, "��������", "���ڶ�ȡͼƬ�����Ժ�...", true, true);
		proDlg.show();

		findAllView(); // ʵ�������
		setButtonListener(); // �����¼� site_auto_text_numver" AutoCompleteTextView
		
		site_auto_text_number = (AutoCompleteTextView)findViewById(R.id.site_auto_text_numver);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(OrderDetailActivity.this, 
					android.R.layout.simple_dropdown_item_1line, OrderStringUtil.siteNumber);	
		site_auto_text_number.setAdapter(adapter);
		
		new Thread(){
			@Override
			public void run() {
				o = new Orders();
				orderDb = new OrderAdapter(OrderDetailActivity.this);
				Cursor c = orderDb.queryOrderListById(id);
				if(c.moveToFirst()){
					do{
						int orderId_index = c.getColumnIndex(OrderAdapter.ORDER_ID);
						o.setOrderId(c.getString(orderId_index));
						
						int name_index = c.getColumnIndex(OrderAdapter.NAME);
						o.setName(c.getString(name_index));
						
						int ddesc_index = c.getColumnIndex(OrderAdapter.DESCRIPTION);
						o.setDesc(c.getString(ddesc_index));
						
						int price_index = c.getColumnIndex(OrderAdapter.PRICE);
						o.setPrice(c.getString(price_index));
						
						int image_index = c.getColumnIndex(OrderAdapter.IMAGE_PATH);
						o.setImage(c.getString(image_index));
						
						int collect_index = c.getColumnIndex(OrderAdapter.COLLECT);
						o.setCollect(c.getString(collect_index));
						
						int create_index = c.getColumnIndex(OrderAdapter.CREATE_AT);
						o.setCreate(c.getString(create_index));
						
						c.moveToNext();
					}while(!c.isAfterLast());
					orderDb.closeDB(c);
					Message m = new Message();
					m.what = OrderStringUtil.OK;
					handler.sendMessage(m);
				}
			}
		}.start();
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error)
				.cacheInMemory(true)
				.cacheOnDisc(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.build();
	}

	/**
	 * ���õ���¼�
	 */
	private void setButtonListener() {
		/**
		 * ���
		 */
		make_order.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(OrderDetailActivity.this);
				final String did = site_auto_text_number.getText().toString().trim();
				if("".equals(did)){
					builder.setTitle("��������λ��").setMessage("����������λ���������������λ�ţ�")
						.setIcon(R.drawable.alert_wanring).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {}
					}).show();
					return;
				}
				boolean f = false;
				for(int i = 0; i < OrderStringUtil.siteNumber.length; i ++){
					if(did.equals(OrderStringUtil.siteNumber[i])){
						f = true;
						break;
					}						
				}
				if(!f){
					builder.setTitle("��Ч").setMessage("��λ����Ч�����������룡\n��Ч����λ��Ϊ��001-100")
					.setIcon(R.drawable.alert_wanring).setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {}
					}).show();
					return;
				}
				proDlg = OrderStringUtil.createProgressDialog(OrderDetailActivity.this, "��������",
						"���ڷ������ݵ�����̨�����Ժ�", true, true);
				proDlg.show();
				new Thread(){
					@Override
					public void run() {
						String url = OrderHttpUtil.BASE_URL + OrderUrlUtil.MAKE_ORDER;
						String requestString = "oid="+id+"&did="+did+"&uid="+str.split(",")[1];
						String res;
						res = OrderHttpUtil.dohttppost(url + requestString).trim();
						Message m = new Message();
						
						if("0".equals(res))
							m.what = OrderStringUtil.MAKE_ORDER_OK;
						else if("-1".equals(res))
							m.what = OrderStringUtil.MAKE_ORDER_ERROR;
						else
							m.what = OrderStringUtil.ERROR;
						handler.sendMessage(m);
						
					}
				}.start();
			}
		});
		
		/**
		 * �ղ�/ȡ���ղ�
		 */
		collect_order.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(OrderDetailActivity.this);
				orderDb.openDB();
				if("-1".equals(o.getCollect())){
					int count = orderDb.collectOrder(id);
					if(count > 0){
						builder.setTitle("�ղسɹ�").setIcon(R.drawable.alert_add);
						builder.setMessage("�ղز˵��ɹ���").setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								// �ػ档����������
								o.setCollect("0");
								collect_order.setText("ȡ���ղ�");
							}
						}).show();
					}
				} else {
					int count = orderDb.disCollectOrder(id);
					if(count > 0){
						builder.setTitle("ȡ���ɹ�").setIcon(R.drawable.alert_ok);
						builder.setMessage("ȡ���ղسɹ���").setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								// �ػ档��������
								o.setCollect("-1");
								collect_order.setText(" �� �� ");
							}
						}).show();
					}
				} 
			}
		});
		
		/**
		 * ���ز�Ʒ�б�
		 */
		findViewById(R.id.go_back_order_list_btn).setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				Intent i = new Intent(OrderDetailActivity.this, OrderListActivity.class);
				OrderStringUtil.putDataIntoIntent(i,str);
				startActivity(i);
			}
		});
	}

	/**
	 * ʵ�������
	 */
	private void findAllView() {
		detail_image = (ImageView)findViewById(R.id.order_detail_iamge);
		detail_price = (TextView)findViewById(R.id.order_detail_price);
		detail_name = (TextView)findViewById(R.id.order_detail_name);
		detail_create = (TextView)findViewById(R.id.order_detail_create);
		detail_desc = (TextView)findViewById(R.id.order_detail_desc);
		
		make_order = (Button)findViewById(R.id.mank_order_detail_btn);
		collect_order = (Button)findViewById(R.id.collect_order_detail_btn);
		
		site_auto_text_number = (AutoCompleteTextView)findViewById(R.id.site_auto_text_numver);
	}
	
	private Handler handler = new Handler(){
		@Override
		public void dispatchMessage(Message msg) {
			AlertDialog.Builder builder = new AlertDialog.Builder(OrderDetailActivity.this);
			proDlg.dismiss();
			
			switch(msg.what){
			case OrderStringUtil.OK:
				setDataToViews();
				break;
			case OrderStringUtil.MAKE_ORDER_OK:
				builder.setTitle("��˳ɹ�").setIcon(R.drawable.alert_ok).setMessage("��˳ɹ������Ժ�")
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							Intent i = new Intent(OrderDetailActivity.this, OrderListActivity.class);
							OrderStringUtil.putDataIntoIntent(i,str);
							startActivity(i);
						}
					}).show();
				break;
			case OrderStringUtil.MAKE_ORDER_ERROR:
				builder.setTitle("����").setIcon(R.drawable.alert_ok).setMessage("��������������ϵ����Ա��")
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
					@Override
					public void onClick(DialogInterface dialog, int which) {}
				}).show();
				break;
			case OrderStringUtil.ERROR:
				builder.setTitle("�ظ�����").setIcon(R.drawable.alert_error).setMessage("���Ѿ�����˲��ˣ��벻Ҫ�ظ�������")
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {						
					@Override
					public void onClick(DialogInterface dialog, int which) {}
				}).show();
				break;
			}
		}
	};
	
	/**
	 * ��������
	 */
	private void setDataToViews() {
		//����һ�����̣߳����ڴ������ϻ�ȡͼƬ  
		String urlString = OrderHttpUtil.BASE_URL + o.getImage();
		imageLoader.displayImage(urlString, detail_image, options);
		//Bitmap map = OrderStringUtil.getBitMapForStringURL(urlString);					
		//detail_image.setImageBitmap(map);
		//����һ�����̣߳����ڴ������ϻ�ȡͼƬ  
        /*new Thread(new Runnable() {  
              
            @Override  
            public void run() {  
                //�������ϻ�ȡͼƬ  
                final Bitmap map = OrderStringUtil.getBitMapForStringURL(urlString);
                  
                try {  
                    Thread.sleep(2000);//�߳�����������  
                } catch (InterruptedException e) {  
                    // TODO Auto-generated catch block  
                    e.printStackTrace();  
                }  
                //alpha.setRepeatCount(0);//ѭ����ʾ    
                //����һ��Runnable����  
                detail_image.post(new Runnable(){  
  
  
                    @Override  
                    public void run() {  
                    	detail_image.setImageBitmap(map);//��ImageView����ʾ�������ϻ�ȡ����ͼƬ  
                    }  
                      
                });  
                  
            }  
        }).start();//�����߳�
*/		detail_price.setText("�۸�" + o.getPrice() + "Ԫ");
		detail_name.setText("������" + o.getName());
		detail_create.setText("����ʱ�䣺" + o.getCreate());
		detail_desc.setText("���\n    " + o.getDesc());	
		
		if("-1".equals(o.getCollect()))
			collect_order.setText(" �� �� ");
		else
			collect_order.setText("ȡ���ղ�");
		collect_order.setVisibility(View.VISIBLE);
		
		make_order.setVisibility(View.VISIBLE);
		findViewById(R.id.go_back_order_list_btn).setVisibility(View.VISIBLE);
	}
	
}

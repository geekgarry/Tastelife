package com.maike.activity;

import java.io.File;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.maike.activity.MenuAllActivity.Extra;
import com.maike.activity.MenuAllActivity.ImageAdapter;
import com.maike.bean.Orders;
import com.maike.util.OrderHttpUtil;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class OrderAllActivity  extends Activity{
	String[] imageUrls;
	protected ImageLoader imageLoader;
	DisplayImageOptions options;
	private String tag1="MenuInfoActivity";
	private List<String> imageurls=new ArrayList<String>();
	private List<String> names=new ArrayList<String>();
	private List<String> descriptions=new ArrayList<String>();
	private List<String> prices=new ArrayList<String>();
	private List<String> types=new ArrayList<String>();
	private List<String> create_dt=new ArrayList<String>();
	//private List<Integer> id_nos=new ArrayList<Integer>();
	private String[] introduces;
	private int[] id_no;
	private String[] name;
	private File cacheDir;
	protected static final int SHOW_RESPONSE=0;
	Handler mhandler;
    private String responsemsg;
    
    protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.orderall);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(OrderAllActivity.this));
		query();
		//���ڴ����ͷ�����Ϣ��Hander
	    mhandler=new Handler(){

			public void handleMessage(Message msg){
	            //�������msg.what=SHOW_RESPONSE��������ƶ�������������������������������߳��ｫSHOW_RESPONSE�ı�
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                    responsemsg=(String)msg.obj;
	                    //����UI�������������ʾ��������
	                    Log.v(tag1,responsemsg);
	            		Type listType=new TypeToken<List<Orders>>(){}.getType();

	            		Gson gson=new Gson();
	            		
	            		List<Orders> list=gson.fromJson(responsemsg, listType);//result���Ǵ�servlet�˴��������ַ���
	            	    // �жϼ����Ƿ���Ч  
	            	    if (list == null || list.size() < 1) {  
	            	        System.out.print("û�����ݣ�");
	            	        Toast.makeText(OrderAllActivity.this, "��Ǹ�������������ݳ������ˣ�", Toast.LENGTH_SHORT).show();
	            	    } else {
	            	    	//images = new ArrayList<ImageView>();
	            	        // ����ͼ�鼯���е����� 
	            	        for (Orders order : list) {
	            	        	//Toast.makeText(this, advertise.getId()+advertise.getContent()+advertise.getImage(), Toast.LENGTH_SHORT).show();
	            	        	//advertise.getId();
	            	        	Log.v(tag1,order.getName());
	            	        	names.add(order.getName());
	            	        	descriptions.add(order.getDescription());
	            	        	prices.add(order.getPrice());
	            	        	types.add(order.getType());
	            	        	create_dt.add(order.getCreate());
	            	        	//advertise.getImage();
	            	        	imageurls.add(OrderHttpUtil.BASE_URL+order.getImgage_path());
	            	        	//imageView1 = new ImageView(this);
	            	        }
	            	     }
	            		/*imageUrls = new String[]{"http://www.baidu.com/img/bdlogo.gif",
	            				"http://pic.sc.chinaz.com/files/pic/pic9/201410/apic6568.jpg",
	            				"http://pic.sc.chinaz.com/files/pic/pic9/201411/apic7677.jpg",
	            				"http://pic1.sc.chinaz.com/files/pic/pic9/201410/apic6867.jpg",
	            				"http://pic.sc.chinaz.com/files/pic/pic9/201411/apic7788.jpg",
	            				"http://pic2.sc.chinaz.com/files/pic/pic9/201411/apic7776.jpg",
	            				"http://pic1.sc.chinaz.com/files/pic/pic9/201410/apic7203.jpg",
	            				"http://pic2.sc.chinaz.com/files/pic/pic9/201410/apic7238.jpg",
	            				"http://pic.sc.chinaz.com/files/pic/pic9/201408/apic5360.jpg",
	            				"http://pic1.sc.chinaz.com/files/pic/pic9/201407/apic5280.jpg",
	            				"http://pic1.sc.chinaz.com/files/pic/pic9/201406/apic4599.jpg"};
	            		
	            		introduces = new String[]{"dfgdd","dfgdd","dfgdd","dfgdd","dfgdd","dfgdd",
	            				"dfgdd","dfgdd","dfgdd","dfgdd","dfgdd"};
	            		name = new String[]{"4������","4������","4������","4������","4������","4������","4������",
	            				"4������","4������","4������","4������"};
	            		id_no = new int[]{1,3,54,56,87,789,78,98,28,87,21};*/
	            		options = new DisplayImageOptions.Builder()
	            		.showStubImage(R.drawable.ic_stub)
	            		.showImageForEmptyUri(R.drawable.ic_empty)
	            		.showImageOnFail(R.drawable.ic_error)
	            		.resetViewBeforeLoading(false)  // default
	            	    .delayBeforeLoading(1000)
	                    .cacheInMemory(true)
	            		.cacheOnDisc(true)
	            		.bitmapConfig(Bitmap.Config.RGB_565)
	            		.build();
	            		GridView gridView = (GridView)findViewById(R.id.gridview);
	            		gridView.setAdapter(new ImageAdapter(OrderAllActivity.this, imageurls, descriptions, names, prices,types,create_dt));
	            		gridView.setOnItemClickListener(new OnItemClickListener() {
	            			@Override
	            			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	            				startImagePagerActivity(position);
	            			}
	            		});
	            }
        	}
        };
		
	}
	
	public void onClick(View v) {
		switch (v.getId()) {
		// TODO Auto-generated method stub
		/*case R.id.dianwo:
	    	Intent intent1=new Intent();
			intent1.setClass(getActivity(), Weather.class);
			intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent1);
			//Toast.makeText(getActivity(), "uiegsibvisdbgbsd", Toast.LENGTH_SHORT).show();
			break;*/
	    default:
	        break;
		}
	}
	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	private void startImagePagerActivity(int position) {
		Intent intent = new Intent();
		intent.setClass(OrderAllActivity.this,OrderOneActivity.class);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putStringArrayListExtra(Extra.IMAGES, (ArrayList<String>) imageurls);
		intent.putStringArrayListExtra("descrptions", (ArrayList<String>) descriptions);
		intent.putStringArrayListExtra("names", (ArrayList<String>) names);
		intent.putStringArrayListExtra("types", (ArrayList<String>) types);
		intent.putStringArrayListExtra("prices", (ArrayList<String>) prices);
		intent.putStringArrayListExtra("create_dt", (ArrayList<String>) create_dt);
		intent.putExtra(Extra.IMAGE_POSITION, position);
		startActivity(intent);
	}
	
	
	public class ImageAdapter extends BaseAdapter {
		
		private LayoutInflater layoutInflater;
        /*private String[] imageUrls;
        private String[] introduces;
        private String[] name;
        private int[] id_no;*/
        private List<String> imageurls1;
        private List<String> descriptions1;
        private List<String> names1;
        private List<String> types1;
        private List<String> prices1;
        private List<String> create_dt1;
        /*public ImageAdapter(Context context,String[] imageUrls,String[] introduces,String[] name,int[] id_no ){
            this.imageUrls = imageUrls;
            this.introduces = introduces;
            this.name = name;
            this.id_no = id_no;
            layoutInflater = LayoutInflater.from(context);
        }
		public ImageAdapter(MenuAllActivity menuAllActivity, String[] imageUrls2, String[] introduces2, String[] name2,
				int[] id_no2) {
			// TODO Auto-generated constructor stub
		}*/
		public ImageAdapter(OrderAllActivity activity, List<String> imageurls, List<String> descriptions,
				List<String> names, List<String> prices, List<String> types, List<String> create_dt) {
			// TODO Auto-generated constructor stub
			this.imageurls1 = imageurls;
            this.descriptions1 = descriptions;
            this.names1 = names;
            this.types1 = types;
            this.prices1 = prices;
            this.create_dt1 = create_dt;
            layoutInflater = LayoutInflater.from(activity);
		}
		
		@Override
		public int getCount() {
			return imageurls.size();
			//return imageUrls.length;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View v = layoutInflater.inflate(R.layout.item_grid_order,null);
			final ImageView imageView;
			TextView tv = null;
			TextView tv1 = null;
			TextView tv2 = null;
			//if (convertView == null) {
				//imageView = (ImageView) getLayoutInflater().inflate(R.layout.item_grid_menu, parent, false);
				imageView = (ImageView) v.findViewById(R.id.image);
	            tv = (TextView) v.findViewById(R.id.describtion);
	            tv1 = (TextView) v.findViewById(R.id.name);
	            tv2 = (TextView) v.findViewById(R.id.price);
			/*} else {
				imageView = (ImageView) convertView;
			}*/
			imageLoader.displayImage(imageurls.get(position), imageView, options);
			tv.setText(descriptions.get(position));
			tv1.setText(names.get(position));
			tv2.setText(prices.get(position));
			return v;
		}
	}
	private void query(){
		//�����߳���������������
        new Thread(new Runnable() {

			@Override
            public void run() {
			String msg=null;
			// url
			String url = OrderHttpUtil.BASE_URL+"OrderServlet";
			msg= OrderHttpUtil.dohttppost(url);
			Message message=new Message();
            message.what=SHOW_RESPONSE;
            //�����������ص����ݴ�ŵ�Message��
            message.obj=msg;
            mhandler.sendMessage(message);
            }
        }).start();
    }
}

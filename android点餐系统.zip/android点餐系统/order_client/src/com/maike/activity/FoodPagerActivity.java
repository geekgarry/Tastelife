package com.maike.activity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.maike.activity.MenuPagerActivity.Extra;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View.OnClickListener;
import android.view.View.OnCreateContextMenuListener;
import android.view.View.OnLongClickListener;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class FoodPagerActivity  extends Activity implements OnClickListener,OnLongClickListener{
	private static final String STATE_POSITION = "STATE_POSITION";
	DisplayImageOptions options;
	ViewPager pager;
	int positionPosition;
	TextView title;
	List<String> imageUrls=new ArrayList<String>();
	List<String> titles=new ArrayList<String>();
	protected ImageLoader imageLoader;
	private Menu menu;
	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.food_viewpager);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(FoodPagerActivity.this));
		
		Bundle bundle = getIntent().getExtras();
		imageUrls = bundle.getStringArrayList(Extra.IMAGES);
		titles = bundle.getStringArrayList("titles");
		//��¼ ��ǰͼƬ��λ�á�
		int pagerPosition = bundle.getInt(Extra.IMAGE_POSITION, 0);
		//�����û�֮ǰ������
		if (savedInstanceState != null) {
			pagerPosition = savedInstanceState.getInt(STATE_POSITION);
		}
		options = new DisplayImageOptions.Builder()
		.showImageForEmptyUri(R.drawable.ic_empty)
		.showImageOnFail(R.drawable.ic_error)
		.resetViewBeforeLoading(true)
		.cacheOnDisc(true)
		.imageScaleType(ImageScaleType.EXACTLY)
		.bitmapConfig(Bitmap.Config.RGB_565)
		.displayer(new FadeInBitmapDisplayer(300))
		.build();
		pager = (ViewPager) findViewById(R.id.pager);
		//pager=(TextView)findViewById(R.id.moredo);
		pager.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(FoodPagerActivity.this, "��������ѡ�", Toast.LENGTH_SHORT).show();
			}
		});
		pager.setOnLongClickListener(new OnLongClickListener() {  
		    @Override  
		    public boolean onLongClick(View v) {  
		        //����true��onCreateContextMenu�����ᱻ����  
		        return false;  
		    }  
		});
		pager.setOnCreateContextMenuListener(new OnCreateContextMenuListener() {  
		    @Override  
		    public void onCreateContextMenu(ContextMenu menu, View v,  
		            ContextMenuInfo menuInfo) {  
		        //ÿ�γ���View�ᴥ���÷���Ȼ�󵯳������Ĳ˵���onLongClickһ�鱻����  
		        menu.setHeaderTitle("����");  
		        menu.add(0, 1, 1, "����").setOnMenuItemClickListener(mOnMenuItemClickListener);  
		        menu.add(0, 2, 2, "����").setOnMenuItemClickListener(mOnMenuItemClickListener);  
		        //menu.add(0, 3, 3, "ȡ��").setOnMenuItemClickListener(mOnMenuItemClickListener);  
		    }  
		});
		pager.setAdapter(new ImagePagerAdapter(this,imageUrls,titles));
		pager.setCurrentItem(pagerPosition);
	}
	
	
	private class ImagePagerAdapter extends PagerAdapter {

		private List<String> images;
		private List<String> titles;
		private LayoutInflater inflater;

		ImagePagerAdapter(Context context,List<String> imageUrls, List<String> title) {
			this.images = imageUrls;
			this.titles=title;
			//inflater = getLayoutInflater();
			inflater=LayoutInflater.from(context);
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			((ViewPager) container).removeView((View) object);
		}

		@Override
		public void finishUpdate(View container) {
		}

		@Override
		public int getCount() {
			return images.size();
		}

		@Override
		public Object instantiateItem(ViewGroup view, int position) {
			positionPosition = position;
			View imageLayout = inflater.inflate(R.layout.food_pager_detail, view, false);
			ImageView imageView = (ImageView) imageLayout.findViewById(R.id.image);
			title=(TextView)imageLayout.findViewById(R.id.title);
			final ProgressBar spinner = (ProgressBar) imageLayout.findViewById(R.id.loading);

			imageLoader.displayImage(images.get(position), imageView, options, new SimpleImageLoadingListener() {
				public void onLoadingStarted(String imageUri, View view) {
					spinner.setVisibility(View.VISIBLE);
				}
				public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
					String message = null;
					// ��ȡͼƬʧ������
					switch (failReason.getType()) {	
						case IO_ERROR:				
							message = "Input/Output error";
							break;
						case DECODING_ERROR:		
							message = "Image can't be decoded";
							break;
						case NETWORK_DENIED:		
							message = "Downloads are denied";
							break;
						case OUT_OF_MEMORY:		    
							message = "Out Of Memory error";
							break;
						case UNKNOWN:				
							message = "Unknown error";
							break;
					}
					Toast.makeText(FoodPagerActivity.this, message, Toast.LENGTH_SHORT).show();

					spinner.setVisibility(View.GONE);
				}
				
				@Override
				public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
					spinner.setVisibility(View.GONE);		
				}
			});
			((ViewPager) view).addView(imageLayout, 0);
			title.setText(titles.get(position));
			/*ids.setText(String.valueOf(id_nos1.get(position)));
			type.setText(types1.get(position));
			introduce.setText(introduces1.get(position));
			star.setText(do_waies1.get(position));
			doway.setText(stars.get(position));*/
			return imageLayout;
		}

		@Override
		public boolean isViewFromObject(View view, Object object) {
			return view.equals(object);
		}

		@Override
		public void restoreState(Parcelable state, ClassLoader loader) {
		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View container) {
		}
	}
	
	//��ť�����˵���������  ���غ�ȡ����
	/*public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, 1, 1, "����");
		menu.add(0, 2, 2, "����");
		menu.add(0, 3, 3, "ȡ��");
		return super.onCreateOptionsMenu(menu);
	}*/
	//Ϊ�����Ĳ˵�ÿһ��ע��ü�����  
	private OnMenuItemClickListener mOnMenuItemClickListener = new OnMenuItemClickListener() {  
	      
	    private String TAG="����";

		@Override  
	    public boolean onMenuItemClick(MenuItem item) {  
	        switch (item.getItemId()) {  
	        case 1:
	        	//����ͼƬ��
				new Thread() {
					public void run() {
						downloadImages(imageUrls.get(positionPosition-1));
					};
				}.start();
	            Log.d(TAG, "����");  
	            break;  
	        case 2:
	        	Toast.makeText(getApplicationContext(), "����", 1000).show();
	            Log.d(TAG, "����");  
	            break;  
	        case 3:  
	            Log.d(TAG, "û����");  
	            break;  
	        default:  
	            break;  
	        }  
	        return false;  
	    }  
	};
	/*public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case 1:
			//����ͼƬ��
			new Thread() {
				public void run() {
					downloadImages(imageUrls.get(positionPosition-1));
				};
			}.start();
			break;

		case 2:
			Toast.makeText(getApplicationContext(), "����", 1000).show();
			break;
		}
		return super.onOptionsItemSelected(item);
	}*/

	//������������ͼƬ��
	public void downloadImages(String imageUrl){
		 HttpGet httpRequest = new HttpGet(imageUrl);  
	        //ȡ��HttpClient ����  
	        HttpClient httpclient = new DefaultHttpClient();  
	        try {  
	            //����httpClient ��ȡ��HttpRestponse  
	            HttpResponse httpResponse = httpclient.execute(httpRequest);  
	            if(httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK){  
	                //ȡ�������Ϣ ȡ��HttpEntiy  
	                HttpEntity httpEntity = httpResponse.getEntity();  
	                //���һ��������  
	                InputStream is = httpEntity.getContent();  
	                System.out.println(is.available());  
	                System.out.println("Get, Yes!");  
	                Log.e("====================", is.available()+"");
	                Log.e("====================", "Get, Yes!");
	                Bitmap bitmap = BitmapFactory.decodeStream(is);  
	                is.close();  
	                //ʱ������
	                SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");//��ȡ��ǰʱ�䣬��һ��ת��Ϊ�ַ���
			        Date date =new Date();
			        String pictureName=format.format(date);
	                saveMyBitmap(pictureName, bitmap);
	            }  
	              
	        } catch (ClientProtocolException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        } catch (IOException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        }  
	}
	
	public void saveMyBitmap(String bitName,Bitmap mBitmap){
		  File f = new File("/sdcard/download/" + bitName + ".jpg");
		  try {
		   f.createNewFile();
		  } catch (IOException e) {
		   // TODO Auto-generated catch block
		 
		  }
		  FileOutputStream fOut = null;
		  try {
		   fOut = new FileOutputStream(f);
		  } catch (FileNotFoundException e) {
		   e.printStackTrace();
		  }
		  mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
		  
		  runOnUiThread(new Runnable() {		
				public void run() {
					//show the image
					 Toast.makeText(getApplicationContext(), "���سɹ�", 1000).show();
				}
			});
		 
		  try {
		   fOut.flush();
		  } catch (IOException e) {
		   e.printStackTrace();
		  }
		  try {
		   fOut.close();
		  } catch (IOException e) {
		   e.printStackTrace();
		  }
		 }

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
}

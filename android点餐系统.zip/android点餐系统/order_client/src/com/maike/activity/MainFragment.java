package com.maike.activity;

import java.io.IOException;

import com.maike.provide.OrderAdapter;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainFragment extends FragmentActivity implements OnClickListener{
	// �ײ��˵�4��Linearlayout
    private LinearLayout ll_first;
    private LinearLayout ll_second;
    private LinearLayout ll_third;
    private LinearLayout ll_fourth;

    // �ײ��˵�4��ImageView
    private ImageView iv_first;
    private ImageView iv_second;
    private ImageView iv_third;
    private ImageView iv_fourth;

    // �ײ��˵�4���˵�����
    private TextView tv_first;
    private TextView tv_second;
    private TextView tv_third;
    private TextView tv_fourth;

    // 4��Fragment
    private Fragment IndexFragment;
    private Fragment MoreFragment;
    private Fragment FindFragment;
    private Fragment PerfileFragment;
    /**
	 * ������
	 */
	private LinearLayout menu_dc;
	private OrderAdapter dbAdapter;
	private String str;
	private ProgressDialog proDlg;
	private String result;
	/**
	 * ��ǰ�˵���Ϣ����ʽΪ��orderId-version,orderId-version ...
	 */
	private String data;
    //private Button dianwo;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.mainfragment);

        // ��ʼ���ؼ�
        initView();
        // ��ʼ���ײ���ť�¼�
        initEvent();
        // ��ʼ�������õ�ǰFragment
        initFragment(0);

    }
	private void initFragment(int index) {
        // ������������V4���µ�Fragment����������Ĺ�����Ҫ��getSupportFragmentManager��ȡ
        FragmentManager fragmentManager = getSupportFragmentManager();
        // ��������
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        // ��������Fragment
        hideFragment(transaction);
        switch (index) {
        case 0:
            if (IndexFragment == null) {
            	IndexFragment = new OrderMainMenu();
                transaction.add(R.id.fl_content, IndexFragment);
            } else {
                transaction.show(IndexFragment);
            }
            break;
        case 1:
            if (MoreFragment == null) {
            	MoreFragment = new MenuAllActivity();
                transaction.add(R.id.fl_content, MoreFragment);
            } else {
                transaction.show(MoreFragment);
            }

            break;
        case 2:
            if (FindFragment == null) {
            	FindFragment = new FindFragment();
                transaction.add(R.id.fl_content, FindFragment);
            } else {
                transaction.show(FindFragment);
            }

            break;
        case 3:
            if (PerfileFragment == null) {
            	PerfileFragment = new PerfileFragment();
                transaction.add(R.id.fl_content, PerfileFragment);
            } else {
                transaction.show(PerfileFragment);
            }

            break;
        default:
            break;
        }
        // �ύ����
        transaction.commit();
    }

    //����Fragment
    private void hideFragment(FragmentTransaction transaction) {
        if (IndexFragment != null) {
            transaction.hide(IndexFragment);
        }
        if (MoreFragment != null) {
            transaction.hide(MoreFragment);
        }
        if (FindFragment != null) {
            transaction.hide(FindFragment);
        }
        if (PerfileFragment != null) {
            transaction.hide(PerfileFragment);
        }
    }

    private void initEvent() {
        // ���ð�ť����
        ll_first.setOnClickListener(this);
        ll_second.setOnClickListener(this);
        ll_third.setOnClickListener(this);
        ll_fourth.setOnClickListener(this);
        //menu_dc.setOnClickListener(this);

    }

    private void initView() {

    	//this.menu_dc = (LinearLayout)findViewById(R.id.ll_menu_dc);
		//menu_dc.setBackgroundResource(0);
        // �ײ��˵�4��Linearlayout
        this.ll_first = (LinearLayout) findViewById(R.id.ll_index);
        this.ll_second = (LinearLayout) findViewById(R.id.ll_more);
        this.ll_third = (LinearLayout) findViewById(R.id.ll_find);
        this.ll_fourth = (LinearLayout) findViewById(R.id.ll_perfile);

        // �ײ��˵�4��ImageView
        this.iv_first = (ImageView) findViewById(R.id.iv_index);
        this.iv_second = (ImageView) findViewById(R.id.iv_more);
        this.iv_third = (ImageView) findViewById(R.id.iv_find);
        this.iv_fourth = (ImageView) findViewById(R.id.iv_perfile);

        // �ײ��˵�4���˵�����
        this.tv_first = (TextView) findViewById(R.id.tv_index);
        this.tv_second = (TextView) findViewById(R.id.tv_more);
        this.tv_third = (TextView) findViewById(R.id.tv_find);
        this.tv_fourth = (TextView) findViewById(R.id.tv_perfile);
    }

    @Override
    public void onClick(View v) {

        // ��ÿ�ε�������еĵײ���ť(ImageView,TextView)��ɫ��Ϊ��ɫ��Ȼ����ݵ����ɫ
        restartBotton();
        // ImageView��TetxView��Ϊ��ɫ��ҳ����֮��ת
        switch (v.getId()) {
        case R.id.ll_index:
            iv_first.setImageResource(R.drawable.index_pressed);
            tv_first.setTextColor(0xff1B940A);
            initFragment(0);
            break;
        case R.id.ll_more:
            iv_second.setImageResource(R.drawable.more_pressed);
            tv_second.setTextColor(0xff1B940A);
            initFragment(1);
            break;
        case R.id.ll_find:
            iv_third.setImageResource(R.drawable.yl_pressed);
            tv_third.setTextColor(0xff1B940A);
            initFragment(2);
            break;
        case R.id.ll_perfile:
            iv_fourth.setImageResource(R.drawable.perfile_pressed);
            tv_fourth.setTextColor(0xff1B940A);
            initFragment(3);
            break;
        /*case R.id.ll_menu_dc:
        	proDlg = OrderStringUtil.createProgressDialog(MainFragment.this, getResources().getString(R.string.pro_title), 
					getResources().getString(R.string.pro_message), true, false);
			
			proDlg.show();
			
			new Thread(){
				private String result;

				@Override
				public void run() {

					*//**
					 * exception Ϊ����������
					 *  ��   ��      ɾ    ��
					 * new,update,delete,error
					 * 010010101101110101000100 ���
					 *//*
					try {
						result = checkOrderVersion();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					Message m = new Message();				
					
					if("exception".equals(result))
						m.what = OrderStringUtil.SERVER_ERROR;
					else if("error".equals(result))
						m.what = OrderStringUtil.SERVER_NO_DATA;
					else if(result.split(",").length == 4)
						m.what = OrderStringUtil.DATA_DETAIL;
					else if("010010101101110101000100".equals(result))
						m.what = OrderStringUtil.GO_ORDER;
					else 
						m.what = OrderStringUtil.ERROR;
					
					handler.sendMessage(m);
				}
			}.start();
            break;*/
        default:
            break;
        }

    }

    private void restartBotton() {
        // ImageView��Ϊ��ɫ
        iv_first.setImageResource(R.drawable.index_normal);
        iv_second.setImageResource(R.drawable.more_normal);
        iv_third.setImageResource(R.drawable.yl_normal);
        iv_fourth.setImageResource(R.drawable.perfile_normal);
        // TextView��Ϊ��ɫ
        tv_first.setTextColor(0xffffffff);
        tv_second.setTextColor(0xffffffff);
        tv_third.setTextColor(0xffffffff);
        tv_fourth.setTextColor(0xffffffff);
    }
    
    /*private String checkOrderVersion() throws IOException{
		dbAdapter = new OrderAdapter(MainFragment.this);
		*//**
		 *  ������
		 *  ���߱���������Ϣ����װ�ַ�����������������
		 *  ���������������ݣ����ظ��½����״̬
		 *//*

		Cursor cursor = dbAdapter.queryOrderVersion();
		
		StringBuilder buf = new StringBuilder();
		if(cursor.moveToFirst()){
			do{
				*//**
				 * �õ�ID
				 *//*
				int idIndex = cursor.getColumnIndex(OrderAdapter.ORDER_ID);
				String id = cursor.getString(idIndex);
				buf.append(id).append("-");
				*//**
				 * �õ��汾
				 *//*
				int versionIndex = cursor.getColumnIndex(OrderAdapter.VERSION);
				String version = cursor.getString(versionIndex);
				buf.append(version).append(",");
				
				cursor.moveToNext();
			}while(!cursor.isAfterLast());
		}
		
		dbAdapter.closeDB();
		data = buf.toString();
		
		if(data.length() > 0)
			data = data.substring(0, data.length()-1);
		
		String queryString = "data=" + data;
		String url = OrderHttpUtil.BASE_URL + OrderUrlUtil.CHECK_ORDER_VERSION + queryString;
		
		String result = OrderHttpUtil.dohttppost(url);
		return result;
	}
    // ��Ϣ����
 	Handler handler = new Handler(){

		@Override
 		public void dispatchMessage(Message msg) {
 			
 			AlertDialog.Builder builder = new AlertDialog.Builder(MainFragment.this);
 			proDlg.dismiss();
 			switch (msg.what){
 			case OrderStringUtil.SERVER_ERROR:
 				builder.setTitle("����������")
 					.setIcon(R.drawable.alert_wanring)
 					.setMessage("�������������Ժ����ԣ�")
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 						}
 					}).show();
 				break;
 			case OrderStringUtil.SERVER_NO_DATA:
 				builder.setTitle("������")
 					.setIcon(R.drawable.alert_error)
 					.setMessage("���������ݣ����ܵ�ˣ�")
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 						}
 					}).show();
 				break;
 			case OrderStringUtil.DATA_DETAIL:
 				final String r[] = result.split(",");
 				if(result==null) {
 					builder.setTitle("������")
 					.setIcon(R.drawable.alert_error)
 					.setMessage("û�и��£����ܵ�ˣ�")
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 						}
 					}).show();
 				}
 				builder.setTitle("ͬ���˵�")
 					.setIcon(R.drawable.alert_ok)
 					.setMessage("����Ҫ��������\n ������" + r[0] + "\t���£�" + r[1] + "\n ɾ����" + r[2] + "\t����" + r[3])
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 							Log.i("UPDATE_TAG", "udpate_data");
 							// code update order ���²˵���
 							
 							Bundle bundle = new Bundle();
 							bundle.putString("new", r[0]);
 							bundle.putString("update", r[1]);
 							bundle.putString("delete", r[2]);
 							bundle.putString("error", r[3]);
 							bundle.putString("data", data);

 							Intent intent = new Intent(MainFragment.this, OrderUpdateActivity.class);
 							intent.putExtra("data", bundle);
 							startActivity(intent);
 						}
 					}).setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {}
 					}).show();
 				break;
 			case OrderStringUtil.GO_ORDER:
 				*//**
 				 * ���
 				 *//*
 				Intent intent = new Intent(MainFragment.this, OrderListActivity.class);				
 				OrderStringUtil.putDataIntoIntent(intent, str);				
 				startActivity(intent);
 				break;
 			case OrderStringUtil.ERROR :
 				builder.setTitle("����")
 					.setIcon(R.drawable.alert_error)
 					.setMessage("���������ԣ�����")
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 							Log.i("UPDATE_TAG", "udpate_data");
 						}
 					}).show();
 				break;
 			case OrderStringUtil.OK:
 				builder.setTitle("���ݲ���Ҫ����")
 					.setIcon(R.drawable.alert_wanring)
 					.setMessage("���ݲ���Ҫ���£�������ֱ�ӵ��")
 					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
 						public void onClick(DialogInterface dialog, int which) {
 							Intent intent = new Intent(MainFragment.this, OrderListActivity.class);
 							OrderStringUtil.putDataIntoIntent(intent, str);
 							startActivity(intent);
 						}
 					}).show();
 				break;
 			}
 		}
 	};*/

}

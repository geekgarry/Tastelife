package com.maike.activity;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import com.maike.wifitallk.config.AppConfig;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.net.DhcpInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("ClickableViewAccessibility")
public class WifiTallk extends Activity
{
	private Button speakButton;// ��ס˵��
	private TextView message;
	private SendSoundsThread sendSoundsThread = new SendSoundsThread();
	private ReceiveSoundsThread receiveSoundsThread = new ReceiveSoundsThread();
	private boolean isFirst = true;
	private WifiManager wifiManager;
	private String TAG="WifiTalk";
	private int serverAddress;
	private String ip;
	private TextView help;

	private String intToIp(int serverAddress) {
		// TODO Auto-generated method stub
		return (serverAddress & 0xFF) + "." +
        ((serverAddress >> 8) & 0xFF) + "." +
        ((serverAddress >> 16) & 0xFF) + "." +
        0;
	}
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.wifitallk);
		wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        //�ж�WiFi�Ƿ���
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, wifiManager.isWifiEnabled() + "δ����wifi", Toast.LENGTH_SHORT).show();
            wifiManager.setWifiEnabled(true);
        }
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ipAddress = wifiInfo.getIpAddress();
        Log.e(TAG, "" + ipAddress);
        //ip = intToIp(ipAddress);
        //��ȡ���ӵ��ȵ��ip
        DhcpInfo dhcpinfo = wifiManager.getDhcpInfo();
        serverAddress = dhcpinfo.serverAddress;
        ip = intToIp(serverAddress);
        //System.out.println("serverAddress-->>" + serverAddress);
        Log.e(TAG, ip);
		message = (TextView) findViewById(R.id.Message);

		speakButton = (Button) findViewById(R.id.speakButton);
		help=(TextView)findViewById(R.id.help);
		help.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(WifiTallk.this,HelpActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
		speakButton.setOnTouchListener(new OnTouchListener()
		{
			@Override
			public boolean onTouch(View v, MotionEvent event)
			{
				if (event.getAction() == MotionEvent.ACTION_DOWN)
				{
					message.setText("�ɿ�����");

					if (isFirst)
					{
						sendSoundsThread.start();
						receiveSoundsThread.start();
						isFirst = false;
					}
					sendSoundsThread.setRunning(true);
					receiveSoundsThread.setRunning(false);
				}
				else if (event.getAction() == MotionEvent.ACTION_UP)
				{
					message.setText("��ס˵��");
					sendSoundsThread.setRunning(false);
					receiveSoundsThread.setRunning(true);
				}
				return false;
			}
		});
	}

	class SendSoundsThread extends Thread
	{
		private AudioRecord recorder = null;
		private boolean isRunning = false;
		private byte[] recordBytes = new byte[640];

		public SendSoundsThread()
		{
			super();

			// ¼����
			int recordBufferSize = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO,
					AudioFormat.ENCODING_PCM_16BIT);
			recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO,
					AudioFormat.ENCODING_PCM_16BIT, recordBufferSize);
		}

		@Override
		public synchronized void run()
		{
			super.run();
			recorder.startRecording();

			while (true)
			{
				if (isRunning)
				{
					try
					{
						DatagramSocket clientSocket = new DatagramSocket();
						InetAddress IP = InetAddress.getByName(ip);// ���������㲥
						//ע�⣺�����Ĺ㲥����������߳���Ȼ�Ѿ�ֹͣ ���ǵ������������������ �ͻ��������㲥 ��������Լ�������
						recorder.read(recordBytes, 0, recordBytes.length);

						DatagramPacket sendPacket = new DatagramPacket(recordBytes, recordBytes.length, IP, AppConfig.Port);
						clientSocket.send(sendPacket);
						clientSocket.close();
					}
					catch (SocketException e)
					{
						e.printStackTrace();
					}
					catch (UnknownHostException e)
					{
						e.printStackTrace();
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
		}

		public void setRunning(boolean isRunning)
		{
			this.isRunning = isRunning;
		}
	}

	class ReceiveSoundsThread extends Thread
	{
		private AudioTrack player = null;
		private boolean isRunning = false;
		private byte[] recordBytes = new byte[640];

		public ReceiveSoundsThread()
		{
			// ������
			int playerBufferSize = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_MONO,
					AudioFormat.ENCODING_PCM_16BIT);
			player = new AudioTrack(AudioManager.STREAM_MUSIC, 44100, AudioFormat.CHANNEL_OUT_MONO,
					AudioFormat.ENCODING_PCM_16BIT, playerBufferSize, AudioTrack.MODE_STREAM);
		}

		@Override
		public synchronized void run()
		{
			super.run();

			try
			{
				@SuppressWarnings("resource")
				DatagramSocket serverSocket = new DatagramSocket(AppConfig.Port);
				while (true)
				{
					if (isRunning)
					{
						DatagramPacket receivePacket = new DatagramPacket(recordBytes, recordBytes.length);
						serverSocket.receive(receivePacket);

						byte[] data = receivePacket.getData();

						player.write(data, 0, data.length);
						player.play();
					}
				}
			}
			catch (SocketException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

		public void setRunning(boolean isRunning)
		{
			this.isRunning = isRunning;
		}
	}
	
	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		android.os.Process.killProcess(android.os.Process.myPid());
	}
}

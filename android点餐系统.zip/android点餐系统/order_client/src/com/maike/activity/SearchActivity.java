package com.maike.activity;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import com.maike.util.XMLParser;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

public class SearchActivity extends Activity implements OnClickListener, OnItemClickListener {

	// �ؼ�
	private EditText editText_search;
	private ImageButton imageButton_refresh_two;
	private ListView listView_city;

	// ����
	private HashMap<String, String> map; // ��ų���map
	private List<String> list_key, list_select; // ���keyֵ
	private Handler handler;

	private ArrayAdapter<String> adapter;

	private int codeInt; // ���ͳ���id

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.search_view);

		// ��ʼ������
		initData();

		// ��ʼ���ؼ�
		initView();

	}

	/**
	 * ��ʼ������
	 */
	private void initData() {
		try {
			list_select = new ArrayList<String>();
			InputStream inputStream = getAssets().open("city_code.xml");
			XMLParser parser = new XMLParser();
			map = parser.getMap(inputStream);
			list_key = parser.getList();

			// System.out.println(map.toString());
			handler = new Handler() {
				public void handleMessage(android.os.Message msg) {
					if (msg.what == 1) {

						// System.out.println("�յ���Ϣ");

						if (list_select.isEmpty()) {
							list_select.add("û��ƥ�����");
						}
						adapter.notifyDataSetChanged();
					}
				}
			};

		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	/**
	 * ��ʼ���ؼ�
	 */
	private void initView() {
		editText_search = (EditText) findViewById(R.id.editText_search);
		editText_search.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO �Զ����ɵķ������
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO �Զ����ɵķ������
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				match();
				
			}
		});
		imageButton_refresh_two = (ImageButton) findViewById(R.id.imageButton_refresh_two);
		imageButton_refresh_two.setOnClickListener(this);

		listView_city = (ListView) findViewById(R.id.listView_city);
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list_select);
		listView_city.setAdapter(adapter);
		listView_city.setOnItemClickListener(this);
	}

	@Override
	public void onClick(View v) {
		match();

		// String city = editText_search.getText().toString().trim();
		// // ����id
		// String code = map.get(city);
		//
		// codeInt = Integer.parseInt(code);
		//
		// System.out.println("���ؽ��" + codeInt);
		//
		// // ���ؽ��
		// setResult(codeInt);
		// // ���س���id
		// finish();

	}

	/**
	 * �ַ���ƥ��
	 */
	private void match() {
		String city = editText_search.getText().toString().trim();
		String str = city + ".*?";

		Pattern pattern = Pattern.compile(str);
		list_select.clear();
		// System.out.println("����ƥ��");
		if (!list_key.isEmpty()) {
			for (int i = 0; i < list_key.size(); i++) {
				if (pattern.matcher(list_key.get(i)).matches()) {

					// System.out.println("ƥ������ĵ���" + list_key.get(i));

					list_select.add(list_key.get(i));
				}
			}
			Message message = new Message();
			message.what = 1;
			handler.sendMessage(message);
		}

		// pattern.m
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

		if (!list_select.isEmpty()) {
			String city = list_select.get(position);

			// System.out.println("����ĳ�����");

			// ����id
			String code = map.get(city);
			codeInt = Integer.parseInt(code);

			// System.out.println("���ؽ��" + codeInt);

			// ���ؽ��
			setResult(codeInt);
			// ���س���id
			finish();
		}

	}

	// @Override
	// public boolean onCreateOptionsMenu(Menu menu) {
	// // Inflate the menu; this adds items to the action bar if it is present.
	// getMenuInflater().inflate(R.menu.search, menu);
	// return true;
	// }
	//
	// @Override
	// public boolean onOptionsItemSelected(MenuItem item) {
	// // Handle action bar item clicks here. The action bar will
	// // automatically handle clicks on the Home/Up button, so long
	// // as you specify a parent activity in AndroidManifest.xml.
	// int id = item.getItemId();
	// if (id == R.id.action_settings) {
	// return true;
	// }
	// return super.onOptionsItemSelected(item);
	// }
	
	
	
}

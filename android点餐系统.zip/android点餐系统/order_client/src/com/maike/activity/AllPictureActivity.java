package com.maike.activity;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.maike.activity.SpiderImgs.ImageAdapter;
import com.maike.util.OrderHttpUtil;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.AdapterView.OnItemClickListener;

public class AllPictureActivity extends Activity{
	List<String> imageUrls=new ArrayList<String>();
	protected ImageLoader imageLoader;
	DisplayImageOptions options;
	private final int SHOW_RESPONSE=0;
	String url = "http://www.27270.com/beautiful/index.html";
	private Handler mhandler;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.picture_all);
		imageLoader = ImageLoader.getInstance();
		imageLoader.init(ImageLoaderConfiguration.createDefault(AllPictureActivity.this));
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.ic_stub)
				.showImageForEmptyUri(R.drawable.ic_empty)
				.showImageOnFail(R.drawable.ic_error)
				.cacheInMemory(true)
				.cacheOnDisc(true)
				.bitmapConfig(Bitmap.Config.RGB_565)
				.build();
		query();
		//���ڴ����ͷ�����Ϣ��Hander
	    mhandler=new Handler(){

			private String tag1="Spider";
			private String responsemsg;

			public void handleMessage(Message msg){
	            //�������msg.what=SHOW_RESPONSE��������ƶ�������������������������������߳��ｫSHOW_RESPONSE�ı�
				super.handleMessage(msg);
	            switch (msg.what){
	                case SHOW_RESPONSE:
	                	try {
	                    responsemsg=(String)msg.obj;
	                    //����UI�������������ʾ��������
	                    Log.v(tag1,responsemsg);
	                    Document document = Jsoup.parse(responsemsg);
	                    
	                    document.setBaseUri(url);
	            		//��ȡ���е�imgԪ��
	            		Elements elements = document.select("img");
	            		for (Element e : elements) {
	            			//��ȡÿ��src�ľ���·��
	            			String src = e.absUrl("src");
	            			//URL urlSource = new URL(src);
	            			//URLConnection urlConnection = urlSource.openConnection();
	            			//String imageName = src.substring(src.lastIndexOf("/") + 1, src.length());
	            			imageUrls.add(src);
	            		}
	            		GridView gridView = (GridView) findViewById(R.id.gridview);
	            		gridView.setAdapter(new ImageAdapter());
	            		gridView.setOnItemClickListener(new OnItemClickListener() {
	            			@Override
	            			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
	            				startImagePagerActivity(position);
	            			}
	            		});
	                	}catch (Exception e) {
							// TODO: handle exception
	                		e.printStackTrace();
						}
	                    break;
	            	}
	        	}
	        };
		/*imageUrls = new String[]{"http://www.baidu.com/img/bdlogo.gif",
				"http://pic.sc.chinaz.com/files/pic/pic9/201410/apic6568.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201411/apic7677.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201410/apic6867.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201411/apic7788.jpg",
				"http://pic2.sc.chinaz.com/files/pic/pic9/201411/apic7776.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201410/apic7203.jpg",
				"http://pic2.sc.chinaz.com/files/pic/pic9/201410/apic7238.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201408/apic5360.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201407/apic5280.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201406/apic4599.jpg",
				"http://pic2.sc.chinaz.com/files/pic/pic9/201406/apic4221.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201405/apic3974.jpg",
				"http://pic2.sc.chinaz.com/files/pic/pic9/201405/apic3859.jpg",
				"http://pic2.sc.chinaz.com/files/pic/pic9/201404/apic195.jpg",
				"http://pic1.sc.chinaz.com/files/pic/pic9/201403/apic669.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic603.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic331.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic306.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic307.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic308.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic309.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic310.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic311.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic312.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic313.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic314.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic315.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic316.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic317.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic318.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic319.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic320.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic321.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic322.jpg",
				"http://pic.sc.chinaz.com/files/pic/pic9/201403/apic323.jpg"};*/		
	}
	public static class Extra {
		public static final String IMAGES = "com.nostra13.example.universalimageloader.IMAGES";
		public static final String IMAGE_POSITION = "com.nostra13.example.universalimageloader.IMAGE_POSITION";
	}
	private void startImagePagerActivity(int position) {
		Intent intent = new Intent(this, ImagePagerActivity.class);
		intent.putStringArrayListExtra(Extra.IMAGES, (ArrayList<String>) imageUrls);
		intent.putExtra(Extra.IMAGE_POSITION, position);
		startActivity(intent);
	}
	
	
	public class ImageAdapter extends BaseAdapter {
		@Override
		public int getCount() {
			return imageUrls.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final ImageView imageView;
			if (convertView == null) {
				imageView = (ImageView) getLayoutInflater().inflate(R.layout.item_grid_image, parent, false);
			} else {
				imageView = (ImageView) convertView;
			}
			imageLoader.displayImage(imageUrls.get(position), imageView, options);
			return imageView;
		}
	}
	private void query(){
		//�����߳���������������
        new Thread(new Runnable() {

			@Override
            public void run() {
			String msg=null;
			// url
			//String url = "http://www.mmonly.cc/mmtp/list_9_1.html";
			msg= OrderHttpUtil.dohttpget(url);
			Message message=new Message();
            message.what=SHOW_RESPONSE;
            //�����������ص����ݴ�ŵ�Message��
            message.obj=msg;
            mhandler.sendMessage(message);
            }
        }).start();
    }
}

package com.maike.bean;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class GetImageView {
	//�ӷ������ϻ�ȡͼƬ����һ
	public static Bitmap getImage(String path){ 
	    
		  try { 
		    HttpURLConnection conn = (HttpURLConnection) new URL(path).openConnection(); 
		    conn.setConnectTimeout(5000); 
		    conn.setRequestMethod("GET"); 
		    System.out.println("�ɹ���ȡ"); 
		    if(conn.getResponseCode() == 200){ 
		      InputStream inputStream = conn.getInputStream(); 
		      Bitmap bitmap = BitmapFactory.decodeStream(inputStream);   
		      return bitmap; 
		    } 
		  } catch (Exception e) { 
		    e.printStackTrace(); 
		  } 
		  return null; 
		}
	//�ӷ������ϻ�ȡͼƬ������
	/*public static Bitmap getImage1(String path){ 
	    
	    HttpGet get = new HttpGet(path); 
	    HttpClient client = new DefaultHttpClient(); 
	    Bitmap pic = null; 
	     try { 
	      HttpResponse response = client.execute(get); 
	      HttpEntity entity = response.getEntity(); 
	      InputStream is = entity.getContent(); 
	  
	      pic = BitmapFactory.decodeStream(is);  // �ؼ������� 
	  } catch (Exception e) { 
	    e.printStackTrace(); 
	  } 
	  return pic; 
	}*/
	//�ӷ������ϻ�ȡͼƬ������
	/*public static Uri getImage2(String path,File cacheDir){ 
	    File localFile = new File(cacheDir,MD5.getMD5(path)+path.substring(path.lastIndexOf("."))); 
	    if(localFile.exists()){ 
	      return Uri.fromFile(localFile); 
	    }else
	    { 
	      HttpURLConnection conn; 
	      try { 
	        conn = (HttpURLConnection) new URL(path).openConnection(); 
	        conn.setConnectTimeout(5000); 
	        conn.setRequestMethod("GET"); 
	        if(conn.getResponseCode() == 200){ 
	          System.out.println("tdw"); 
	          FileOutputStream outputStream = new FileOutputStream(localFile); 
	          InputStream inputStream = conn.getInputStream(); 
	          byte[] buffer = new byte[1024]; 
	          int length = 0; 
	          while((length=inputStream.read(buffer))!=-1){ 
	            outputStream.write(buffer, 0, length); 
	          } 
	          inputStream.close(); 
	          outputStream.close(); 
	          return Uri.fromFile(localFile); 
	        } 
	      } catch (Exception e) { 
	        // TODO Auto-generated catch block 
	        e.printStackTrace(); 
	      } 
	    } 
	    return null;   
	  }*/
	//�����ַ��������ӷ�������ȡ�����ݴ��뱾�ص��ļ��У�����ļ��Ѵ��ڣ�����Ҫ�ӷ��������»�ȡ���ݡ��ڹ��ܴ����У�
	/*image.setImageURI(getImage2(path, cache));
	cache = new File(Environment.getExternalStorageDirectory(),"cache"); 
	if(!cache.exists()){ 
		  cache.mkdirs(); 
		}*/ 
}

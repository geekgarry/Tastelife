package com.maike.bean;

/**
 * ����������
 * 
 * @author annoy
 */
public class WeatherBean {

	public String city; // ����
	public int code; // ����id
	public String week; // ����
	public String date_y; // ����
	public String temp; // �¶�
	public String wind; // ��
	public String weather; // ����
	public String pm; // pmֵ

	public String tempCurrent; // ���������
	public String windCurrent; // ����ķ���

	public WeatherBean() {
		// TODO �Զ����ɵĹ��캯�����
	}

	public WeatherBean(String city, int code, String week, String date_y, String temp, String wind, String weather,
			String pm, String tempCurrent, String windCurrent) {
		super();
		this.city = city;
		this.code = code;
		this.week = week;
		this.date_y = date_y;
		this.temp = temp;
		this.wind = wind;
		this.weather = weather;
		this.pm = pm;
		this.tempCurrent = tempCurrent;
		this.windCurrent = windCurrent;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public String getDate_y() {
		return date_y;
	}

	public void setDate_y(String date_y) {
		this.date_y = date_y;
	}

	public String getTemp() {
		return temp;
	}

	public void setTemp(String temp) {
		this.temp = temp;
	}

	public String getWind() {
		return wind;
	}

	public void setWind(String wind) {
		this.wind = wind;
	}

	public String getWeather() {
		return weather;
	}

	public void setWeather(String weather) {
		this.weather = weather;
	}

	public String getPm() {
		return pm;
	}

	public void setPm(String pm) {
		this.pm = pm;
	}

	public String getTempCurrent() {
		return tempCurrent;
	}

	public void setTempCurrent(String tempCurrent) {
		this.tempCurrent = tempCurrent;
	}

	public String getWindCurrent() {
		return windCurrent;
	}

	public void setWindCurrent(String windCurrent) {
		this.windCurrent = windCurrent;
	}

	@Override
	public String toString() {
		return "WeatherBean [city=" + city + ", code=" + code + ", week=" + week + ", date_y=" + date_y + ", temp="
				+ temp + ", wind=" + wind + ", weather=" + weather + ", pm=" + pm + ", tempCurrent=" + tempCurrent
				+ ", windCurrent=" + windCurrent + "]";
	}
	
}

package com.maike.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class OrderDataBaseUtil extends SQLiteOpenHelper{
	
	private static final String DATABASE_NAME = "order_db";
	private static final int DATABASE_VERSION = 2;
	
	private static final String DEFAULT_ID = "_id integer primary key autoincrement";
	
	private String tableName;
	private String columns[];
	private String constraints[];
	
	/**
	 * @param context
	 * @param tbname ���� table_1
	 * @param cols ���� column_1
	 * @param cons ��Լ������  Integer not null 
	 */
	public OrderDataBaseUtil(Context ctx, String tbname, String cols[], String cons[]) {
		super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
		
//		super(context, name, factory, version);
		/**
		 * context  to use to open or create the database
		 * name of the database file, or null for an in-memory database
		 * factory to use for creating cursor objects, or null for the default
		 * version number of the database (starting at 1); if the database is older, onUpgrade(SQLiteDatabase, int, int) will be used to upgrade the database  
		 */
		tableName = tbname;
		columns = cols;
		constraints = cons;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		StringBuilder sql = new StringBuilder();
		sql.append("CREATE TABLE ").append(tableName);
		sql.append("(").append(DEFAULT_ID).append(",");
		for(int i = 0; i < columns.length; i++){
			if(i < columns.length -1)
				sql.append(columns[i]).append(" ").append(constraints[i]).append(",");
			else 
				sql.append(columns[i]).append(" ").append(constraints[i]);
		}
		sql.append(")");
		Log.i("CREATE_TB==>>", sql.toString());
		db.execSQL(sql.toString());
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		String sql = "DROP TABLE IF EXISTS " + tableName;
		Log.i("DROP_TB==>>", sql);
		db.execSQL(sql);
		onCreate(db);
	}

	/**
	 * �õ�һ���ɶ������ݿ�
	 * @return
	 */
	public SQLiteDatabase openReadDB() {
		return this.getReadableDatabase();
	}
	
	/**
	 * �õ�һ���ɶ�����д�����ݿ�
	 * @return
	 */
	public SQLiteDatabase openWriteDB() {
		return getWritableDatabase();
	}

}

package com.maike.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.accounts.NetworkErrorException;

public class OrderHttpUtil {

	/**
	 * �����Ӧ�Ļ���URL
	 */
	public static final String BASE_URL = "http://120.78.165.181:8080/order_server/";
	
	private static OrderHttpUtil instance = null;

    public static synchronized OrderHttpUtil getInstance() {
        if (instance == null) {
            instance = new OrderHttpUtil();
        }
        return instance;
    }

    private OrderHttpUtil() {
    }

    // post
    public static String dohttppost(String mUrl){
    	HttpURLConnection httpURLConnection =null;
    	StringBuilder sb = new StringBuilder();
    	try {
        URL url = new URL(mUrl);
        httpURLConnection = (HttpURLConnection) url.openConnection();//��ʼ������HttpURLConnectionʵ��
        httpURLConnection.setConnectTimeout(5000);//�Ƽ�����������ʱ
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setDoInput(true);
        httpURLConnection.setUseCaches(false);
        httpURLConnection.setRequestProperty("Content-type", "application/x-java-serialized-object");
        httpURLConnection.setInstanceFollowRedirects(true);
        httpURLConnection.setRequestMethod("POST");
        //���ò���
        /*OutputStream outputStream = connection.getOutputStream();
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream,"UTF-8"));
        writer.write(getStringFromOutput(parms));

        writer.flush();
        writer.close();
        outputStream.close();*/
        int responseCode = httpURLConnection.getResponseCode();// ���ô˷����Ͳ�����ʹ��conn.connect()����
        if(responseCode == HttpURLConnection.HTTP_OK){
            BufferedReader reader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
            String temp;
            while((temp = reader.readLine()) != null){
                sb.append(temp);
            }
            reader.close();
        }else{
            return "connection error:" + httpURLConnection.getResponseCode();
        }

        httpURLConnection.disconnect();
	    }catch (Exception e){
	        return e.toString();
	    }
	    return sb.toString();
	    }

    // get
    public static String dohttpget(String mUrl){
    	HttpURLConnection httpURLConnection =null;
    	try {
        URL url = new URL(mUrl);
        httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setConnectTimeout(5000);//�Ƽ�����������ʱ
        httpURLConnection.setReadTimeout(5000);
        httpURLConnection.setRequestMethod("GET");
        //httpURLConnection.connect();

        // String msg = httpURLConnection.getResponseMessage();

        /*InputStreamReader inputStreamReader = new InputStreamReader(httpURLConnection.getInputStream());
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        StringBuilder builder = new StringBuilder();
        for (String s = bufferedReader.readLine(); s != null; s = bufferedReader.readLine()) {
            builder.append(s);
        }

        return builder.toString();*/
        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {

            InputStream is = httpURLConnection.getInputStream();
            String response = getStringFromInputStream(is);
            return response;
        } else {
            throw new NetworkErrorException("response status is "+responseCode);
        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	
	        if (httpURLConnection != null) {
	        	httpURLConnection.disconnect();
	        }
	    }
	
	    return null;
    }
    private static String getStringFromInputStream(InputStream is)
            throws IOException {
        /*ByteArrayOutputStream os = new ByteArrayOutputStream();
        // ģ����� ��������
        byte[] buffer = new byte[1024];
        int len = -1;
        while ((len = is.read(buffer)) != -1) {
            os.write(buffer, 0, len);
        }
        is.close();
        String state = os.toString();// �����е�����ת�����ַ���,���õı�����utf-8(ģ����Ĭ�ϱ���)
        os.close();
        return state;*/
    	BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuffer sb = new StringBuffer();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line + "\n");
        }
        String respose = sb.toString();
        return respose;
    }
	/**
	 * ͨ��URL��ȡHttpGet����
	 * @param url
	 * @return HttpGet
	 *//*
	private static HttpGet getHttpGet(String url){
		HttpGet httpGet = new HttpGet(url);
		return httpGet;
	}
	
	*//**
	 * ͨ��URL��ȡHttpPost����
	 * @param url
	 * @return HttpPost
	 *//*
	public static HttpPost getHttpPost(String url){
		HttpPost httpPost = new HttpPost(url);
		return httpPost;
	}
	
	*//**
	 * ͨ�� HttpGet�����ȡHttpResponse����
	 * @param httpGet
	 * @return HttpResponse
	 * @throws ClientProtocolException
	 * @throws IOException
	 *//*
	private static HttpResponse getHttpResponse(HttpGet httpGet) throws ClientProtocolException, IOException{
		HttpResponse response = new DefaultHttpClient().execute(httpGet);
		return response;
	}
	
	*//**
	 * ͨ��HttpPost��ȡHttpPonse����
	 * @param HttpPost
	 * @return httpPost
	 * @throws ClientProtocolException
	 * @throws IOException
	 *//*
	private static HttpResponse getHttpResponse(HttpPost httpPost) throws ClientProtocolException, IOException{
		HttpResponse response = new DefaultHttpClient().execute(httpPost);
		return response;
	}
	
	*//**
	 * ��URL�����HttpPost���󣬷��ͣ��õ���ѯ��� �����쳣 ���� "exception"
	 * @param url
	 * @return resultString 
	 *//*
	public static String getHttpPostResultForUrl(String url){
		HttpPost httpPost = getHttpPost(url);
		String resultString = null;
		
		try {
			HttpResponse response = getHttpResponse(httpPost);
			
			if(response.getStatusLine().getStatusCode() == 200)
				resultString = EntityUtils.toString(response.getEntity());				
			
		} catch (ClientProtocolException e) {
			resultString = "exception";
			e.printStackTrace();
		} catch (IOException e) {
			resultString = "exception";
			e.printStackTrace();
		}
		
		return resultString;
	}
	
	*//**
	 * ����Post���󣬵õ���ѯ��� �����쳣 ���� "exception"
	 * @param url
	 * @return resultString
	 *//*
	public static String getHttpPostResultForRequest(HttpPost httpPost){
		String resultString = null;
		
		try {
			HttpResponse response = getHttpResponse(httpPost);
			
			if(response.getStatusLine().getStatusCode() == 200)
				resultString = EntityUtils.toString(response.getEntity());				
			
		} catch (ClientProtocolException e) {
			resultString = "exception";
			e.printStackTrace();
		} catch (IOException e) {
			resultString = "exception";
			e.printStackTrace();
		}
		
		return resultString;
	}
	*//**
	 * ��URL�����HttpGet���󣬷��ͣ��õ���ѯ��� �����쳣 ���� "exception"
	 * @param url
	 * @return resultString
	 *//*
	public static String getHttpGetResultForUrl(String url){
		HttpGet httpGet = getHttpGet(url);
		String resultString = null;
		
		try {
			HttpResponse response = getHttpResponse(httpGet);
			if(response.getStatusLine().getStatusCode() == 200)
				resultString = EntityUtils.toString(response.getEntity());
		} catch (ClientProtocolException e) {
			resultString = "exception";
			e.printStackTrace();
		} catch (IOException e) {
			resultString = "exception";
			e.printStackTrace();
		}
		
		return resultString;
	}
	
	*//**
	 * ����Get���󣬵õ���ѯ��� �����쳣 ���� "exception"
	 * @param url
	 * @return resultString
	 *//*
	public static String getHttpGetResultForRequest(HttpGet httpGet){
		String resultString = null;
		try {
			HttpResponse response = getHttpResponse(httpGet);
			if(response.getStatusLine().getStatusCode() == 200)
				resultString = EntityUtils.toString(response.getEntity());
		} catch (ClientProtocolException e) {
			resultString = "exception";
			e.printStackTrace();
		} catch (IOException e) {
			resultString = "exception";
			e.printStackTrace();
		}
		
		return resultString;
	}*/
	
}

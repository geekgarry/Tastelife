package com.maike.application;

import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

import android.app.Application;
import android.content.Context;
import android.graphics.Bitmap.Config;

public class MyApplication extends Application{
	public static DisplayImageOptions options; 

    @Override
    public void onCreate() {
        super.onCreate();
        initImageLoader( getApplicationContext() );
    }

    private void initImageLoader(Context context) {
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(context)
        .memoryCacheExtraOptions(750, 370)
        .threadPriority(Thread.NORM_PRIORITY - 2)
        .denyCacheImageMultipleSizesInMemory()
        .diskCacheExtraOptions(720, 1280, null)
        .diskCacheFileNameGenerator(new Md5FileNameGenerator())
        .diskCacheSize(50 * 1024 * 1024) // 50 Mb
        .tasksProcessingOrder(QueueProcessingType.LIFO)
        .diskCacheFileCount( 500 )
        .build();
        ImageLoader.getInstance().init( config );

        initOptions() ;
    }

    private void initOptions(){
        options = new DisplayImageOptions.Builder()
        .cacheInMemory(true)  //�����ڴ滺��
        .cacheOnDisk(true)    //���ô��̻���
        .considerExifParams(true)
        .bitmapConfig(Config.RGB_565 )
        .build();
    }
}
